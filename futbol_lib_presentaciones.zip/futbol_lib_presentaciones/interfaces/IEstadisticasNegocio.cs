﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IEstadisticasNegocio
    {
        List<Estadisticas> Consultar();
        Estadisticas Guardar(Estadisticas entidad);
        Estadisticas Modificar(Estadisticas entidad);
        Estadisticas Borrar(int id);
    }
}