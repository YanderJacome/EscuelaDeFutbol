﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IEvaluacionesNegocio
    {
        List<Evaluaciones> Consultar();
        Evaluaciones Guardar(Evaluaciones entidad);
        Evaluaciones Modificar(Evaluaciones entidad);
        Evaluaciones Borrar(int id);
    }
}