﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IMensualidadesNegocio
    {
        List<Mensualidades> Consultar();
        Mensualidades Guardar(Mensualidades entidad);
        Mensualidades Modificar(Mensualidades entidad);
        Mensualidades Borrar(Mensualidades entidad);
    }
}