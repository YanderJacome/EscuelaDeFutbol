﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IPersonasNegocio
    {
        List<Personas> Consultar();
        Personas Guardar(Personas entidad);
        Personas Modificar(Personas entidad);
        Personas Borrar(int id);
    }
}