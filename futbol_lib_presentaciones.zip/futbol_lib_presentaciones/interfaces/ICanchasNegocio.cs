﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface ICanchasNegocio
    {
        List<Canchas> Consultar();
        Canchas Guardar(Canchas entidad);
        Canchas Modificar(Canchas entidad);
        Canchas Borrar(Canchas entidad);
    }
}