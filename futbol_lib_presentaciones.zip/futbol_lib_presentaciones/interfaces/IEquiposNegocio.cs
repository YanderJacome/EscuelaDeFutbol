﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IEquiposNegocio
    {
        List<Equipos> Consultar();
        Equipos Guardar(Equipos entidad);
        Equipos Modificar(Equipos entidad);
        Equipos Borrar(int id);
    }
}

