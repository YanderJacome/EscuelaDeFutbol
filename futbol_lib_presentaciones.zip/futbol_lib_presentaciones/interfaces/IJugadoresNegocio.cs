﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IJugadoresNegocio
    {
        List<Jugadores> Consultar();
        Jugadores Guardar(Jugadores entidad);
        Jugadores Modificar(Jugadores entidad);
        Jugadores Borrar(int id);
    }
}