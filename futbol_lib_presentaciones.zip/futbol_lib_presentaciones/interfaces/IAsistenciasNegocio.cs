﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IAsistenciasNegocio
    {
        List<Asistencias> Consultar();
        Asistencias Guardar(Asistencias entidad);
        Asistencias Modificar(Asistencias entidad);
        Asistencias Borrar(Asistencias entidad);
    }
}