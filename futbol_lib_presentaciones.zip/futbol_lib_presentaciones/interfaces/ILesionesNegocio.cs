﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface ILesionesNegocio
    {
        List<Lesiones> Consultar();
        Lesiones Guardar(Lesiones entidad);
        Lesiones Modificar(Lesiones entidad);
        Lesiones Borrar(int id);
    }
}