﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IInscripcionesNegocio
    {
        List<Inscripciones> Consultar();
        Inscripciones Guardar(Inscripciones entidad);
        Inscripciones Modificar(Inscripciones entidad);
        Inscripciones Borrar(Inscripciones entidad);
    }
}