﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IEntrenamientosNegocio
    {
        List<Entrenamientos> Consultar();
        Entrenamientos Guardar(Entrenamientos entidad);
        Entrenamientos Modificar(Entrenamientos entidad);
        Entrenamientos Borrar(int id);
    }
}