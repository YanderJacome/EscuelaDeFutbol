﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IHorariosNegocio
    {
        List<Horarios> Consultar();
        Horarios Guardar(Horarios entidad);
        Horarios Modificar(Horarios entidad);
        Horarios Borrar(Horarios entidad);
    }
}