﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface ITorneosNegocio
    {
        List<Torneos> Consultar();
        Torneos Guardar(Torneos entidad);
        Torneos Modificar(Torneos entidad);
        Torneos Borrar(int id);
    }
}