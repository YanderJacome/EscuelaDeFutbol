﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.interfaces
{
    public interface IPosicionesNegocio
    {
        List<Posiciones> Consultar();
        Posiciones Guardar(Posiciones entidad);
        Posiciones Modificar(Posiciones entidad);
        Posiciones Borrar(int id);
    }
}