﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_presentaciones.interfaces;
using Newtonsoft.Json;


namespace futbol_lib_presentaciones.implementaciones
{
    public class PersonasNegocio : IPersonasNegocio
    {
        private readonly string _baseUrl;

        public PersonasNegocio()
        {
            _baseUrl = "http://localhost:5064";
        }

        public List<Personas> Consultar()
        {
            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Personas/Consultar" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                return new List<Personas>();

            return JsonConvert.DeserializeObject<List<Personas>>(respuesta["Valor"].ToString()!)!;
        }

        public Personas Guardar(Personas entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardo");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Personas/Guardar" },
                { "Entidad", entidad },
                { "Metodo", "POST" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Personas>(respuesta["Valor"].ToString()!)!;
        }

        public Personas Modificar(Personas entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Personas/Modificar" },
                { "Entidad", entidad },
                { "Metodo", "PUT" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Personas>(respuesta["Valor"].ToString()!)!;
        }

        public Personas Borrar(int id)
        {
            if (id <= 0)
                throw new Exception("ID inválido");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Personas/Borrar" },
                { "Entidad", id },
                { "Metodo", "DELETE" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Personas>(respuesta["Valor"].ToString()!)!;
        }
    }
}