﻿using futbol_lib_presentaciones.interfaces;
using Newtonsoft.Json;
using System.Text;


namespace futbol_lib_presentaciones.implementaciones
{
    public class Comunicaciones : IComunicaciones
    {
        public async Task<Dictionary<string, object>> Ejecutar(Dictionary<string, object> datos)
        {
            var url = datos["Url"].ToString();
            datos.Remove("Url");
            var stringData = datos.ContainsKey("Entidad") ?
                JsonConvert.SerializeObject(datos["Entidad"]) : "{}";
            var body = new StringContent(stringData, Encoding.UTF8, "application/json");

            var httpClient = new HttpClient();
            httpClient.Timeout = new TimeSpan(0, 4, 0);

     
            var method = datos.ContainsKey("Metodo") ? datos["Metodo"].ToString() : "GET";
            HttpResponseMessage message;

            switch (method)
            {
                case "POST":
                    message = await httpClient.PostAsync(url, body);
                    break;
                case "PUT":
                    message = await httpClient.PutAsync(url, body);
                    break;
                case "DELETE":
                    var request = new HttpRequestMessage(HttpMethod.Delete, url);
                    request.Content = body;
                    message = await httpClient.SendAsync(request);
                    break;
                default:
                    message = await httpClient.GetAsync(url);
                    break;
            }

            if (!message.IsSuccessStatusCode)
                throw new Exception("Error Comunicacion");

            var resp = await message.Content.ReadAsStringAsync();
            httpClient.Dispose();

            resp = Replace(resp);
            return new Dictionary<string, object>() {
                { "Valor", resp }
            };
        }

        private string Replace(string resp)
        {
            return resp.Replace("\\\\r\\\\n", "")
                .Replace("\\r\\n", "")
                .Replace("\\", "")
                .Replace("\\\"", "\"")
                .Replace("\"", "'")
                .Replace("'[", "[")
                .Replace("]'", "]")
                .Replace("'{'", "{'")
                .Replace("\\\\", "\\")
                .Replace("'}'", "'}")
                .Replace("}'", "}")
                .Replace("\\n", "")
                .Replace("\\r", "")
                .Replace("    ", "")
                .Replace("'{", "{")
                .Replace("\"", "")
                .Replace("  ", "")
                .Replace("null", "''");
        }
    }
}