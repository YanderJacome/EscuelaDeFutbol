﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_presentaciones.interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.implementaciones
{
    public class CanchasNegocio : ICanchasNegocio
    {
        private readonly string _baseUrl;

        public CanchasNegocio()
        {
            _baseUrl = "http://localhost:5064";
        }

        public List<Canchas> Consultar()
        {
            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Canchas/Consultar" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                return new List<Canchas>();

            return JsonConvert.DeserializeObject<List<Canchas>>(respuesta["Valor"].ToString()!)!;
        }

        public Canchas Guardar(Canchas entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardo");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Canchas/Guardar" },
                { "Entidad", entidad },
                { "Metodo", "POST" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Canchas>(respuesta["Valor"].ToString()!)!;
        }

        public Canchas Modificar(Canchas entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Canchas/Modificar" },
                { "Entidad", entidad },
                { "Metodo", "PUT" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Canchas>(respuesta["Valor"].ToString()!)!;
        }

        public Canchas Borrar(Canchas entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede borrar");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Canchas/Borrar" },
                { "Entidad", entidad },
                { "Metodo", "DELETE" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Canchas>(respuesta["Valor"].ToString()!)!;
        }
    }
}