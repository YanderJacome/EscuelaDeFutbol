﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_presentaciones.interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.implementaciones
{
    public class HorariosNegocio : IHorariosNegocio
    {
        private readonly string _baseUrl;

        public HorariosNegocio()
        {
            _baseUrl = "http://localhost:5064";
        }

        public List<Horarios> Consultar()
        {
            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Horarios/Consultar" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                return new List<Horarios>();

            return JsonConvert.DeserializeObject<List<Horarios>>(respuesta["Valor"].ToString()!)!;
        }

        public Horarios Guardar(Horarios entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardo");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Horarios/Guardar" },
                { "Entidad", entidad },
                { "Metodo", "POST" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Horarios>(respuesta["Valor"].ToString()!)!;
        }

        public Horarios Modificar(Horarios entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Horarios/Modificar" },
                { "Entidad", entidad },
                { "Metodo", "PUT" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Horarios>(respuesta["Valor"].ToString()!)!;
        }

        public Horarios Borrar(Horarios entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede borrar");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Horarios/Borrar" },
                { "Entidad", entidad },
                { "Metodo", "DELETE" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Horarios>(respuesta["Valor"].ToString()!)!;
        }
    }
}