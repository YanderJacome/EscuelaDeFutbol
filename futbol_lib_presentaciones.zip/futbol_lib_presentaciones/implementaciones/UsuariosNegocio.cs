﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_presentaciones.interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.implementaciones
{
    public class UsuariosNegocio : IUsuariosNegocio
    {
        private readonly string _baseUrl;

        public UsuariosNegocio()
        {
            _baseUrl = "http://localhost:5064";
        }

        public List<Usuarios> Consultar()
        {
            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Usuarios/Consultar" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                return new List<Usuarios>();

            return JsonConvert.DeserializeObject<List<Usuarios>>(respuesta["Valor"].ToString()!)!;
        }

        public Usuarios Guardar(Usuarios entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardo");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Usuarios/Guardar" },
                { "Entidad", entidad },
                { "Metodo", "POST" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Usuarios>(respuesta["Valor"].ToString()!)!;
        }

        public Usuarios Modificar(Usuarios entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Usuarios/Modificar" },
                { "Entidad", entidad },
                { "Metodo", "PUT" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Usuarios>(respuesta["Valor"].ToString()!)!;
        }

        public Usuarios Borrar(Usuarios entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede borrar");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Usuarios/Borrar" },
                { "Entidad", entidad },
                { "Metodo", "DELETE" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Usuarios>(respuesta["Valor"].ToString()!)!;
        }
    }
}