﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_presentaciones.interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_presentaciones.implementaciones
{
    public class PagosNegocio : IPagosNegocio
    {
        private readonly string _baseUrl;

        public PagosNegocio()
        {
            _baseUrl = "http://localhost:5064";
        }

        public List<Pagos> Consultar()
        {
            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Pagos/Consultar" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                return new List<Pagos>();

            return JsonConvert.DeserializeObject<List<Pagos>>(respuesta["Valor"].ToString()!)!;
        }

        public Pagos Guardar(Pagos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardo");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Pagos/Guardar" },
                { "Entidad", entidad },
                { "Metodo", "POST" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Pagos>(respuesta["Valor"].ToString()!)!;
        }

        public Pagos Modificar(Pagos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Pagos/Modificar" },
                { "Entidad", entidad },
                { "Metodo", "PUT" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Pagos>(respuesta["Valor"].ToString()!)!;
        }

        public Pagos Borrar(int id)
        {
            if (id <= 0)
                throw new Exception("ID inválido");

            var comunicaciones = new Comunicaciones();
            var datos = new Dictionary<string, object>
            {
                { "Url", $"{_baseUrl}/Pagos/Borrar" },
                { "Entidad", id },
                { "Metodo", "DELETE" }
            };

            var task = comunicaciones.Ejecutar(datos);
            task.Wait();
            var respuesta = task.Result;

            if (!respuesta.ContainsKey("Valor"))
                throw new Exception("No funciono");

            return JsonConvert.DeserializeObject<Pagos>(respuesta["Valor"].ToString()!)!;
        }
    }
}