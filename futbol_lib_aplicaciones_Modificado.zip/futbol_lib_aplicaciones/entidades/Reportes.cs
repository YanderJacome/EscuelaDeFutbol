﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Reportes
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public string? Tipo { get; set; }
        public string? Parametros { get; set; }
        public string? ArchivoUrl { get; set; }
        public int GeneradoPor { get; set; }
        public DateTime? FechaGeneracion { get; set; }

        [ForeignKey("GeneradoPor")]
        public Usuarios? _GeneradoPor { get; set; }
    }
}