﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class CategoriasNegocio : ICategoriasNegocio
    {
        private IConexion? iConexion;

        public List<Categorias> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Categorias.ToList();
        }

        public Categorias ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var categoria = iConexion.Categorias.Find(id);
            if (categoria == null)
                throw new Exception("No existe la categoría");
            return categoria;
        }

        public List<Categorias> ConsultarActivas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Categorias.Where(c => c.Activa).ToList();
        }

        public List<Categorias> ConsultarPorEdad(int edad)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Categorias.Where(c => c.EdadMinima <= edad && edad <= c.EdadMaxima && c.Activa).ToList();
        }

        public Categorias Guardar(Categorias entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Categorias.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.EdadMinima,
                entidad.EdadMaxima,
                entidad.Activa
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Categorias",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Categorias Modificar(Categorias entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Categorias.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la categoría");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.EdadMinima,
                existente.EdadMaxima,
                existente.Activa
            });

            existente.Nombre = entidad.Nombre;
            existente.EdadMinima = entidad.EdadMinima;
            existente.EdadMaxima = entidad.EdadMaxima;
            existente.Activa = entidad.Activa;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.EdadMinima,
                entidad.EdadMaxima,
                entidad.Activa
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Categorias",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Categorias Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Categorias.Find(id);
            if (existente == null)
                throw new Exception("No existe la categoría");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.EdadMinima,
                existente.EdadMaxima,
                existente.Activa
            });

            iConexion.Categorias.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Categorias",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}