﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class LesionesNegocio : ILesionesNegocio
    {
        private IConexion? iConexion;

        public List<Lesiones> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Lesiones
                .Include(l => l._Jugador)
                .ToList();
        }

        public Lesiones ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var lesion = iConexion.Lesiones
                .Include(l => l._Jugador)
                .FirstOrDefault(l => l.Id == id);
            if (lesion == null)
                throw new Exception("No existe la lesión");
            return lesion;
        }

        public List<Lesiones> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Lesiones
                .Where(l => l.Jugador == jugadorId)
                .Include(l => l._Jugador)
                .ToList();
        }

        public List<Lesiones> ConsultarActivas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Lesiones
                .Where(l => l.FechaFin == null)
                .Include(l => l._Jugador)
                .ToList();
        }

        public Lesiones Guardar(Lesiones entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.FechaInicio = DateTime.Now;

            iConexion.Lesiones.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Tipo,
                entidad.FechaInicio,
                entidad.FechaFin,
                entidad.Observacion,
                entidad.Jugador
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Lesiones",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Lesiones Modificar(Lesiones entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Lesiones.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la lesión");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Tipo,
                existente.FechaInicio,
                existente.FechaFin,
                existente.Observacion,
                existente.Jugador
            });

            existente.Tipo = entidad.Tipo;
            existente.FechaInicio = entidad.FechaInicio;
            existente.FechaFin = entidad.FechaFin;
            existente.Observacion = entidad.Observacion;
            existente.Jugador = entidad.Jugador;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Tipo,
                entidad.FechaInicio,
                entidad.FechaFin,
                entidad.Observacion,
                entidad.Jugador
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Lesiones",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Lesiones Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Lesiones.Find(id);
            if (existente == null)
                throw new Exception("No existe la lesión");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Tipo,
                existente.FechaInicio,
                existente.FechaFin,
                existente.Observacion,
                existente.Jugador
            });

            iConexion.Lesiones.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Lesiones",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}