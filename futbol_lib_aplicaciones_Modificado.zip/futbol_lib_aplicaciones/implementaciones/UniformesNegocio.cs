﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class UniformesNegocio : IUniformesNegocio
    {
        private IConexion? iConexion;

        public List<Uniformes> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Uniformes
                .Include(u => u._Equipo)
                .ToList();
        }

        public Uniformes ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var uniforme = iConexion.Uniformes.Find(id);
            if (uniforme == null)
                throw new Exception("No existe el uniforme");
            return uniforme;
        }

        public List<Uniformes> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Uniformes.Where(u => u.Equipo == equipoId).ToList();
        }

        public List<Uniformes> ConsultarPorTalla(string talla)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Uniformes.Where(u => u.Talla == talla).ToList();
        }

        public Uniformes Guardar(Uniformes entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Uniformes.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.ColorPrincipal,
                entidad.ColorSecundario,
                entidad.Talla,
                entidad.NumeroDisponible,
                entidad.Equipo
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Uniformes",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Uniformes Modificar(Uniformes entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Uniformes.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el uniforme");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.ColorPrincipal,
                existente.ColorSecundario,
                existente.Talla,
                existente.NumeroDisponible,
                existente.Equipo
            });

            existente.ColorPrincipal = entidad.ColorPrincipal;
            existente.ColorSecundario = entidad.ColorSecundario;
            existente.Talla = entidad.Talla;
            existente.NumeroDisponible = entidad.NumeroDisponible;
            existente.Equipo = entidad.Equipo;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.ColorPrincipal,
                entidad.ColorSecundario,
                entidad.Talla,
                entidad.NumeroDisponible,
                entidad.Equipo
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Uniformes",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Uniformes Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Uniformes.Find(id);
            if (existente == null)
                throw new Exception("No existe el uniforme");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.ColorPrincipal,
                existente.ColorSecundario,
                existente.Talla,
                existente.NumeroDisponible,
                existente.Equipo
            });

            iConexion.Uniformes.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Uniformes",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}