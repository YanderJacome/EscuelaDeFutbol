﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class UsuariosNegocio : IUsuariosNegocio
    {
        private IConexion? iConexion;

        public List<Usuarios> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Usuarios
                .Include(u => u._Rol)
                .ToList();
        }

        public Usuarios ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var usuario = iConexion.Usuarios.Find(id);
            if (usuario == null)
                throw new Exception("No existe el usuario");
            return usuario;
        }

        public Usuarios ConsultarPorUsername(string username)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var usuario = iConexion.Usuarios.FirstOrDefault(u => u.Username == username);
            if (usuario == null)
                throw new Exception("No existe el usuario");
            return usuario;
        }

        public Usuarios Guardar(Usuarios entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.FechaCreacion = DateTime.Now;
            entidad.Activo = true;

            iConexion.Usuarios.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Username,
                entidad.Email,
                entidad.Rol,
                entidad.Activo
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Usuarios",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Usuarios Modificar(Usuarios entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Usuarios.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el usuario");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Username,
                existente.Email,
                existente.Rol,
                existente.Activo
            });

            existente.Username = entidad.Username;
            existente.Email = entidad.Email;
            existente.Rol = entidad.Rol;
            existente.Activo = entidad.Activo;

            if (!string.IsNullOrEmpty(entidad.PasswordHash))
            {
                existente.PasswordHash = entidad.PasswordHash;
            }

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Username,
                entidad.Email,
                entidad.Rol,
                entidad.Activo
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Usuarios",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Usuarios Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Usuarios.Find(id);
            if (existente == null)
                throw new Exception("No existe el usuario");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Username,
                existente.Email,
                existente.Rol,
                existente.Activo
            });

            iConexion.Usuarios.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Usuarios",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Usuarios Autenticar(string username, string password)
        {
            var usuario = ConsultarPorUsername(username);

            if (usuario.PasswordHash != password)
                throw new Exception("Contraseña incorrecta");

            if (!usuario.Activo)
                throw new Exception("Usuario inactivo");

            return usuario;
        }

        public bool CambiarPassword(int id, string nuevaPassword)
        {
            var usuario = ConsultarPorId(id);
            usuario.PasswordHash = nuevaPassword;
            Modificar(usuario);
            return true;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}