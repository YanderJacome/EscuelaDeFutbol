﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class PosicionesNegocio : IPosicionesNegocio
    {
        private IConexion? iConexion;

        public List<Posiciones> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Posiciones
                .Include(p => p._Equipo)
                .Include(p => p._Torneo)
                .ToList();
        }

        public Posiciones ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var posicion = iConexion.Posiciones
                .Include(p => p._Equipo)
                .Include(p => p._Torneo)
                .FirstOrDefault(p => p.Id == id);
            if (posicion == null)
                throw new Exception("No existe la posición");
            return posicion;
        }

        public List<Posiciones> ConsultarPorTorneo(int torneoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Posiciones
                .Where(p => p.Torneo == torneoId)
                .Include(p => p._Equipo)
                .Include(p => p._Torneo)
                .OrderByDescending(p => p.Puntos)
                .ToList();
        }

        public List<Posiciones> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Posiciones
                .Where(p => p.Equipo == equipoId)
                .Include(p => p._Equipo)
                .Include(p => p._Torneo)
                .ToList();
        }

        public Posiciones Guardar(Posiciones entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Posiciones.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Puntos,
                entidad.PartidosJugados,
                entidad.DiferenciaGoles,
                entidad.Equipo,
                entidad.Torneo
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Posiciones",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Posiciones Modificar(Posiciones entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Posiciones.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la posición");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Puntos,
                existente.PartidosJugados,
                existente.DiferenciaGoles,
                existente.Equipo,
                existente.Torneo
            });

            existente.Puntos = entidad.Puntos;
            existente.PartidosJugados = entidad.PartidosJugados;
            existente.DiferenciaGoles = entidad.DiferenciaGoles;
            existente.Equipo = entidad.Equipo;
            existente.Torneo = entidad.Torneo;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Puntos,
                entidad.PartidosJugados,
                entidad.DiferenciaGoles,
                entidad.Equipo,
                entidad.Torneo
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Posiciones",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Posiciones Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Posiciones.Find(id);
            if (existente == null)
                throw new Exception("No existe la posición");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Puntos,
                existente.PartidosJugados,
                existente.DiferenciaGoles,
                existente.Equipo,
                existente.Torneo
            });

            iConexion.Posiciones.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Posiciones",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}