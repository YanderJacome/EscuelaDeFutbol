﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class NotificacionesNegocio : INotificacionesNegocio
    {
        private IConexion? iConexion;

        public List<Notificaciones> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Notificaciones
                .Include(n => n._Jugador)
                .ToList();
        }

        public Notificaciones ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var notificacion = iConexion.Notificaciones.Find(id);
            if (notificacion == null)
                throw new Exception("No existe la notificación");
            return notificacion;
        }

        public List<Notificaciones> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Notificaciones.Where(n => n.Jugador == jugadorId).ToList();
        }

        public List<Notificaciones> ConsultarNoLeidas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Notificaciones.Where(n => !n.Leida).ToList();
        }

        public List<Notificaciones> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Notificaciones.Where(n => n.Fecha.Date == fecha.Date).ToList();
        }

        public Notificaciones Guardar(Notificaciones entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.Fecha = DateTime.Now;
            entidad.Leida = false;

            iConexion.Notificaciones.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Mensaje,
                entidad.Fecha,
                entidad.Leida,
                entidad.Jugador
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Notificaciones",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Notificaciones Modificar(Notificaciones entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Notificaciones.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la notificación");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Mensaje,
                existente.Fecha,
                existente.Leida,
                existente.Jugador
            });

            existente.Mensaje = entidad.Mensaje;
            existente.Fecha = entidad.Fecha;
            existente.Leida = entidad.Leida;
            existente.Jugador = entidad.Jugador;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Mensaje,
                entidad.Fecha,
                entidad.Leida,
                entidad.Jugador
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Notificaciones",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Notificaciones Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Notificaciones.Find(id);
            if (existente == null)
                throw new Exception("No existe la notificación");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Mensaje,
                existente.Fecha,
                existente.Leida,
                existente.Jugador
            });

            iConexion.Notificaciones.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Notificaciones",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}