﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class EntrenadoresNegocio : IEntrenadoresNegocio
    {
        private IConexion? iConexion;

        public List<Entrenadores> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Entrenadores.ToList();
        }

        public Entrenadores ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var entrenador = iConexion.Entrenadores.Find(id);
            if (entrenador == null)
                throw new Exception("No existe el entrenador");
            return entrenador;
        }

        public List<Entrenadores> ConsultarPorRol(int rolId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Entrenadores.Where(e => e.Rol == rolId).ToList();
        }

        public Entrenadores Guardar(Entrenadores entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Entrenadores.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Documento,
                entidad.FechaNacimiento,
                entidad.Telefono,
                entidad.Email,
                entidad.Direccion,
                entidad.Activo,
                entidad.Licencia,
                entidad.Experiencia,
                entidad.Especialidad,
                entidad.Rol
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Entrenadores",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Entrenadores Modificar(Entrenadores entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Entrenadores.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el entrenador");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Documento,
                existente.FechaNacimiento,
                existente.Telefono,
                existente.Email,
                existente.Direccion,
                existente.Activo,
                existente.Licencia,
                existente.Experiencia,
                existente.Especialidad,
                existente.Rol
            });

            existente.Nombre = entidad.Nombre;
            existente.Documento = entidad.Documento;
            existente.FechaNacimiento = entidad.FechaNacimiento;
            existente.Telefono = entidad.Telefono;
            existente.Email = entidad.Email;
            existente.Direccion = entidad.Direccion;
            existente.Activo = entidad.Activo;
            existente.Licencia = entidad.Licencia;
            existente.Experiencia = entidad.Experiencia;
            existente.Especialidad = entidad.Especialidad;
            existente.Rol = entidad.Rol;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Documento,
                entidad.FechaNacimiento,
                entidad.Telefono,
                entidad.Email,
                entidad.Direccion,
                entidad.Activo,
                entidad.Licencia,
                entidad.Experiencia,
                entidad.Especialidad,
                entidad.Rol
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Entrenadores",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Entrenadores Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Entrenadores.Find(id);
            if (existente == null)
                throw new Exception("No existe el entrenador");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Documento,
                existente.FechaNacimiento,
                existente.Telefono,
                existente.Email,
                existente.Direccion,
                existente.Activo,
                existente.Licencia,
                existente.Experiencia,
                existente.Especialidad,
                existente.Rol
            });

            iConexion.Entrenadores.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Entrenadores",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}