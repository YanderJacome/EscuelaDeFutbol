﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class MensualidadesNegocio : IMensualidadesNegocio
    {
        private IConexion? iConexion;

        public List<Mensualidades> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Mensualidades
                .Include(m => m._Jugador)
                .ToList();
        }

        public Mensualidades ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var mensualidad = iConexion.Mensualidades.Find(id);
            if (mensualidad == null)
                throw new Exception("No existe la mensualidad");
            return mensualidad;
        }

        public List<Mensualidades> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Mensualidades.Where(m => m.Jugador == jugadorId).ToList();
        }

        public List<Mensualidades> ConsultarPorEstado(bool pagada)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Mensualidades.Where(m => m.Pagada == pagada).ToList();
        }

        public List<Mensualidades> ConsultarVencidas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var hoy = DateTime.Now;
            return iConexion.Mensualidades.Where(m => !m.Pagada && m.FechaVencimiento.Date < hoy.Date).ToList();
        }

        public Mensualidades Guardar(Mensualidades entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Mensualidades.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.ValorBase,
                entidad.Recargo,
                entidad.FechaVencimiento,
                entidad.Pagada,
                entidad.Jugador
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Mensualidades",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Mensualidades Modificar(Mensualidades entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Mensualidades.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la mensualidad");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.ValorBase,
                existente.Recargo,
                existente.FechaVencimiento,
                existente.Pagada,
                existente.Jugador
            });

            existente.ValorBase = entidad.ValorBase;
            existente.Recargo = entidad.Recargo;
            existente.FechaVencimiento = entidad.FechaVencimiento;
            existente.Pagada = entidad.Pagada;
            existente.Jugador = entidad.Jugador;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.ValorBase,
                entidad.Recargo,
                entidad.FechaVencimiento,
                entidad.Pagada,
                entidad.Jugador
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Mensualidades",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Mensualidades Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Mensualidades.Find(id);
            if (existente == null)
                throw new Exception("No existe la mensualidad");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.ValorBase,
                existente.Recargo,
                existente.FechaVencimiento,
                existente.Pagada,
                existente.Jugador
            });

            iConexion.Mensualidades.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Mensualidades",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}