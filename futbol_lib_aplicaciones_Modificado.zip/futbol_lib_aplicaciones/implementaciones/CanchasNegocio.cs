﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class CanchasNegocio : ICanchasNegocio
    {
        private IConexion? iConexion;

        public List<Canchas> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Canchas.ToList();
        }

        public Canchas ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var cancha = iConexion.Canchas.Find(id);
            if (cancha == null)
                throw new Exception("No existe la cancha");
            return cancha;
        }

        public List<Canchas> ConsultarDisponibles()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Canchas.Where(c => c.Disponible).ToList();
        }

        public List<Canchas> ConsultarPorCapacidad(int capacidadMinima)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Canchas.Where(c => c.Capacidad >= capacidadMinima).ToList();
        }

        public Canchas Guardar(Canchas entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Canchas.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Ubicacion,
                entidad.Latitud,
                entidad.Longitud,
                entidad.Capacidad,
                entidad.Disponible
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Canchas",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Canchas Modificar(Canchas entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Canchas.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la cancha");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Ubicacion,
                existente.Latitud,
                existente.Longitud,
                existente.Capacidad,
                existente.Disponible
            });

            existente.Nombre = entidad.Nombre;
            existente.Ubicacion = entidad.Ubicacion;
            existente.Latitud = entidad.Latitud;
            existente.Longitud = entidad.Longitud;
            existente.Capacidad = entidad.Capacidad;
            existente.Disponible = entidad.Disponible;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Ubicacion,
                entidad.Latitud,
                entidad.Longitud,
                entidad.Capacidad,
                entidad.Disponible
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Canchas",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Canchas Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Canchas.Find(id);
            if (existente == null)
                throw new Exception("No existe la cancha");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Ubicacion,
                existente.Latitud,
                existente.Longitud,
                existente.Capacidad,
                existente.Disponible
            });

            iConexion.Canchas.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Canchas",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}