﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class EvaluacionesNegocio : IEvaluacionesNegocio
    {
        private IConexion? iConexion;

        public List<Evaluaciones> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Evaluaciones
                .Include(e => e._Jugador)
                .ToList();
        }

        public Evaluaciones ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var evaluacion = iConexion.Evaluaciones
                .Include(e => e._Jugador)
                .FirstOrDefault(e => e.Id == id);
            if (evaluacion == null)
                throw new Exception("No existe la evaluación");
            return evaluacion;
        }

        public List<Evaluaciones> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Evaluaciones
                .Where(e => e.Jugador == jugadorId)
                .Include(e => e._Jugador)
                .ToList();
        }

        public Evaluaciones Guardar(Evaluaciones entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Evaluaciones.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Resistencia,
                entidad.Velocidad,
                entidad.Tecnica,
                entidad.Disciplina,
                entidad.Jugador
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Evaluaciones",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Evaluaciones Modificar(Evaluaciones entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Evaluaciones.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la evaluación");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Resistencia,
                existente.Velocidad,
                existente.Tecnica,
                existente.Disciplina,
                existente.Jugador
            });

            existente.Resistencia = entidad.Resistencia;
            existente.Velocidad = entidad.Velocidad;
            existente.Tecnica = entidad.Tecnica;
            existente.Disciplina = entidad.Disciplina;
            existente.Jugador = entidad.Jugador;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Resistencia,
                entidad.Velocidad,
                entidad.Tecnica,
                entidad.Disciplina,
                entidad.Jugador
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Evaluaciones",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Evaluaciones Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Evaluaciones.Find(id);
            if (existente == null)
                throw new Exception("No existe la evaluación");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Resistencia,
                existente.Velocidad,
                existente.Tecnica,
                existente.Disciplina,
                existente.Jugador
            });

            iConexion.Evaluaciones.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Evaluaciones",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}
