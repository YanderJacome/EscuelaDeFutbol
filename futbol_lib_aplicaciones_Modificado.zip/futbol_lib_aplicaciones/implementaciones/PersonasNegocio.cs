﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class PersonasNegocio : IPersonasNegocio
    {
        private IConexion? iConexion;

        public List<Personas> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Personas.ToList();
        }

        public Personas ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var persona = iConexion.Personas.Find(id);
            if (persona == null)
                throw new Exception("No existe la persona");
            return persona;
        }

        public Personas Guardar(Personas entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Personas.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Documento,
                entidad.FechaNacimiento,
                entidad.Telefono,
                entidad.Email,
                entidad.Direccion,
                entidad.Activo
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Personas",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Personas Modificar(Personas entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Personas.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la persona");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Documento,
                existente.FechaNacimiento,
                existente.Telefono,
                existente.Email,
                existente.Direccion,
                existente.Activo
            });

            existente.Nombre = entidad.Nombre;
            existente.Documento = entidad.Documento;
            existente.FechaNacimiento = entidad.FechaNacimiento;
            existente.Telefono = entidad.Telefono;
            existente.Email = entidad.Email;
            existente.Direccion = entidad.Direccion;
            existente.Activo = entidad.Activo;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Documento,
                entidad.FechaNacimiento,
                entidad.Telefono,
                entidad.Email,
                entidad.Direccion,
                entidad.Activo
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Personas",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Personas Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Personas.Find(id);
            if (existente == null)
                throw new Exception("No existe la persona");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Documento,
                existente.FechaNacimiento,
                existente.Telefono,
                existente.Email,
                existente.Direccion,
                existente.Activo
            });

            iConexion.Personas.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Personas",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}