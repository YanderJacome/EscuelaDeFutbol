﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class AsistenciasNegocio : IAsistenciasNegocio
    {
        private IConexion? iConexion;

        public List<Asistencias> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Asistencias
                .Include(a => a._Jugador)
                .Include(a => a._Entrenamiento)
                .ToList();
        }

        public Asistencias ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var asistencia = iConexion.Asistencias.Find(id);
            if (asistencia == null)
                throw new Exception("No existe la asistencia");
            return asistencia;
        }

        public List<Asistencias> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Asistencias.Where(a => a.Jugador == jugadorId).ToList();
        }

        public List<Asistencias> ConsultarPorEntrenamiento(int entrenamientoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Asistencias.Where(a => a.Entrenamiento == entrenamientoId).ToList();
        }

        public List<Asistencias> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Asistencias.Where(a => a.Fecha.Date == fecha.Date).ToList();
        }

        public Asistencias Guardar(Asistencias entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.Fecha = DateTime.Now;

            iConexion.Asistencias.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Fecha,
                entidad.Presente,
                entidad.Observacion,
                entidad.Entrenamiento,
                entidad.Jugador
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Asistencias",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Asistencias Modificar(Asistencias entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Asistencias.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la asistencia");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Fecha,
                existente.Presente,
                existente.Observacion,
                existente.Entrenamiento,
                existente.Jugador
            });

            existente.Fecha = entidad.Fecha;
            existente.Presente = entidad.Presente;
            existente.Observacion = entidad.Observacion;
            existente.Entrenamiento = entidad.Entrenamiento;
            existente.Jugador = entidad.Jugador;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Fecha,
                entidad.Presente,
                entidad.Observacion,
                entidad.Entrenamiento,
                entidad.Jugador
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Asistencias",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Asistencias Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Asistencias.Find(id);
            if (existente == null)
                throw new Exception("No existe la asistencia");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Fecha,
                existente.Presente,
                existente.Observacion,
                existente.Entrenamiento,
                existente.Jugador
            });

            iConexion.Asistencias.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Asistencias",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}