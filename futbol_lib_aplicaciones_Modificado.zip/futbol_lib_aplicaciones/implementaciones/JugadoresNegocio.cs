﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;


namespace futbol_lib_aplicaciones.implementaciones
{
    public class JugadoresNegocio : IJugadoresNegocio
    {
        private IConexion? iConexion;

        public List<Jugadores> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Jugadores.ToList();
        }

        public Jugadores ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var jugador = iConexion.Jugadores.Find(id);
            if (jugador == null)
                throw new Exception("No existe el jugador");
            return jugador;
        }

        public List<Jugadores> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Jugadores.Where(j => j.Equipo == equipoId).ToList();
        }

        public Jugadores Guardar(Jugadores entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Jugadores.Add(entidad);
            iConexion.SaveChanges();

            // ✅ Guardar valores como JSON COMPLETO
            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Posicion,
                entidad.Equipo
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Jugadores",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Jugadores Modificar(Jugadores entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Jugadores.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el jugador");

            // Guardar valores anteriores como JSON COMPLETO
            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Posicion,
                existente.Equipo
            });

            // Actualizar
            existente.Nombre = entidad.Nombre;
            existente.Documento = entidad.Documento;
            existente.FechaNacimiento = entidad.FechaNacimiento;
            existente.Telefono = entidad.Telefono;
            existente.Email = entidad.Email;
            existente.Direccion = entidad.Direccion;
            existente.Activo = entidad.Activo;
            existente.Posicion = entidad.Posicion;
            existente.PiernaHabil = entidad.PiernaHabil;
            existente.Equipo = entidad.Equipo;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Posicion,
                entidad.Equipo
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            // Registrar auditoría
            var auditoria = new Auditorias()
            {
                Tabla = "Jugadores",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

           
            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Jugadores Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Jugadores.Find(id);
            if (existente == null)
                throw new Exception("No existe el jugador");

            // Guardar valores para auditoría
            var valorAnterior = JsonConvert.SerializeObject(new { existente.Nombre, existente.Posicion, existente.Equipo });

            iConexion.Jugadores.Remove(existente);
            iConexion.SaveChanges();

            // ✅ Registrar auditoría
            var auditoria = new Auditorias()
            {
                Tabla = "Jugadores",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        // Métodos auxiliares para obtener usuario e IP
        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}