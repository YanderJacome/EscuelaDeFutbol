﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class HorariosNegocio : IHorariosNegocio
    {
        private IConexion? iConexion;

        public List<Horarios> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Horarios
                .Include(h => h._Equipo)
                .ToList();
        }

        public Horarios ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var horario = iConexion.Horarios
                .Include(h => h._Equipo)
                .FirstOrDefault(h => h.Id == id);
            if (horario == null)
                throw new Exception("No existe el horario");
            return horario;
        }

        public List<Horarios> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Horarios
                .Where(h => h.Equipo == equipoId)
                .Include(h => h._Equipo)
                .ToList();
        }

        public List<Horarios> ConsultarPorDia(DayOfWeek dia)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Horarios
                .Where(h => h.Dia == dia && h.Activo)
                .Include(h => h._Equipo)
                .ToList();
        }

        public List<Horarios> ConsultarActivos()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Horarios
                .Where(h => h.Activo)
                .Include(h => h._Equipo)
                .ToList();
        }

        public Horarios Guardar(Horarios entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Horarios.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Dia,
                entidad.HoraInicio,
                entidad.HoraFin,
                entidad.Activo,
                entidad.Equipo
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Horarios",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Horarios Modificar(Horarios entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Horarios.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el horario");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Dia,
                existente.HoraInicio,
                existente.HoraFin,
                existente.Activo,
                existente.Equipo
            });

            existente.Dia = entidad.Dia;
            existente.HoraInicio = entidad.HoraInicio;
            existente.HoraFin = entidad.HoraFin;
            existente.Activo = entidad.Activo;
            existente.Equipo = entidad.Equipo;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Dia,
                entidad.HoraInicio,
                entidad.HoraFin,
                entidad.Activo,
                entidad.Equipo
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Horarios",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Horarios Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Horarios.Find(id);
            if (existente == null)
                throw new Exception("No existe el horario");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Dia,
                existente.HoraInicio,
                existente.HoraFin,
                existente.Activo,
                existente.Equipo
            });

            iConexion.Horarios.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Horarios",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}