﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class TorneosNegocio : ITorneosNegocio
    {
        private IConexion? iConexion;

        public List<Torneos> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Torneos.ToList();
        }

        public Torneos ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var torneo = iConexion.Torneos.Find(id);
            if (torneo == null)
                throw new Exception("No existe el torneo");
            return torneo;
        }

        public List<Torneos> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Torneos.Where(t => t.FechaInicio.Date <= fecha.Date && t.FechaFin.Date >= fecha.Date).ToList();
        }

        public List<Torneos> ConsultarActivos()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var hoy = DateTime.Now;
            return iConexion.Torneos.Where(t => t.FechaInicio.Date <= hoy.Date && t.FechaFin.Date >= hoy.Date).ToList();
        }

        public Torneos Guardar(Torneos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Torneos.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.FechaInicio,
                entidad.FechaFin,
                entidad.Ubicacion
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Torneos",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Torneos Modificar(Torneos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Torneos.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el torneo");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.FechaInicio,
                existente.FechaFin,
                existente.Ubicacion
            });

            existente.Nombre = entidad.Nombre;
            existente.FechaInicio = entidad.FechaInicio;
            existente.FechaFin = entidad.FechaFin;
            existente.Ubicacion = entidad.Ubicacion;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.FechaInicio,
                entidad.FechaFin,
                entidad.Ubicacion
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Torneos",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Torneos Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Torneos.Find(id);
            if (existente == null)
                throw new Exception("No existe el torneo");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.FechaInicio,
                existente.FechaFin,
                existente.Ubicacion
            });

            iConexion.Torneos.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Torneos",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}