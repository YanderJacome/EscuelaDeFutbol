﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class EquiposNegocio : IEquiposNegocio
    {
        private IConexion? iConexion;

        public List<Equipos> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var equipos = iConexion.Equipos
                .Select(e => new Equipos
                {
                    Id = e.Id,
                    Nombre = e.Nombre,
                    Activo = e.Activo,
                    Entrenador = e.Entrenador,
                    Categoria = e.Categoria,
                    _Entrenador = e._Entrenador != null ? new Entrenadores
                    {
                        Id = e._Entrenador.Id,
                        Nombre = e._Entrenador.Nombre
                    } : null,
                    _Categoria = e._Categoria != null ? new Categorias
                    {
                        Id = e._Categoria.Id,
                        Nombre = e._Categoria.Nombre
                    } : null
                })
                .ToList();

            return equipos;
        }
        public Equipos ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var equipo = iConexion.Equipos.Find(id);
            if (equipo == null)
                throw new Exception("No existe el equipo");
            return equipo;
        }

        public List<Equipos> ConsultarPorCategoria(int categoriaId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Equipos.Where(e => e.Categoria == categoriaId).ToList();
        }

        public List<Equipos> ConsultarPorEntrenador(int entrenadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Equipos.Where(e => e.Entrenador == entrenadorId).ToList();
        }

        public Equipos Guardar(Equipos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            if (string.IsNullOrEmpty(entidad.Nombre))
                throw new Exception("El nombre es requerido");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Equipos.Add(entidad);
            iConexion.SaveChanges();

            // ✅ Guardar valores como JSON COMPLETO
            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Activo,
                entidad.Entrenador,
                entidad.Categoria
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Equipos",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Equipos Modificar(Equipos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Equipos.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el equipo");

            // Guardar valores anteriores como JSON COMPLETO
            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Activo,
                existente.Entrenador,
                existente.Categoria
            });

            // Actualizar
            existente.Nombre = entidad.Nombre;
            existente.Activo = entidad.Activo;
            existente.Entrenador = entidad.Entrenador;
            existente.Categoria = entidad.Categoria;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Activo,
                entidad.Entrenador,
                entidad.Categoria
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            // Registrar auditoría
            var auditoria = new Auditorias()
            {
                Tabla = "Equipos",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Equipos Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Equipos.Find(id);
            if (existente == null)
                throw new Exception("No existe el equipo");

            // Guardar valores para auditoría
            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Activo,
                existente.Entrenador,
                existente.Categoria
            });

            iConexion.Equipos.Remove(existente);
            iConexion.SaveChanges();

            // ✅ Registrar auditoría
            var auditoria = new Auditorias()
            {
                Tabla = "Equipos",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}