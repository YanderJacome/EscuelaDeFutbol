﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class PagosNegocio : IPagosNegocio
    {
        private IConexion? iConexion;

        public List<Pagos> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Pagos
                .Include(p => p._Jugador)
                .ToList();
        }

        public Pagos ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var pago = iConexion.Pagos.Find(id);
            if (pago == null)
                throw new Exception("No existe el pago");
            return pago;
        }

        public List<Pagos> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Pagos.Where(p => p.Jugador == jugadorId).ToList();
        }

        public List<Pagos> ConsultarPorEstado(bool estado)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Pagos.Where(p => p.Estado == estado).ToList();
        }

        public Pagos Guardar(Pagos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Pagos.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Fecha,
                entidad.Valor,
                entidad.Descuento,
                entidad.Estado,
                entidad.Jugador
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Pagos",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Pagos Modificar(Pagos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Pagos.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el pago");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Fecha,
                existente.Valor,
                existente.Descuento,
                existente.Estado,
                existente.Jugador
            });

            existente.Fecha = entidad.Fecha;
            existente.Valor = entidad.Valor;
            existente.Descuento = entidad.Descuento;
            existente.Estado = entidad.Estado;
            existente.Jugador = entidad.Jugador;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Fecha,
                entidad.Valor,
                entidad.Descuento,
                entidad.Estado,
                entidad.Jugador
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Pagos",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Pagos Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Pagos.Find(id);
            if (existente == null)
                throw new Exception("No existe el pago");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Fecha,
                existente.Valor,
                existente.Descuento,
                existente.Estado,
                existente.Jugador
            });

            iConexion.Pagos.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Pagos",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}