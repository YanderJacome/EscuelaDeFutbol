﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class PartidosNegocio : IPartidosNegocio
    {
        private IConexion? iConexion;

        public List<Partidos> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Partidos
                .Include(p => p._Equipo)
                .Include(p => p._Cancha)
                .ToList();
        }
        public Partidos ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var partido = iConexion.Partidos.Find(id);
            if (partido == null)
                throw new Exception("No existe el partido");
            return partido;
        }

        public List<Partidos> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Partidos.Where(p => p.Equipo == equipoId).ToList();
        }

        public List<Partidos> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Partidos.Where(p => p.Fecha.Date == fecha.Date).ToList();
        }

        public Partidos Guardar(Partidos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Partidos.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Fecha,
                entidad.GolesFavor,
                entidad.GolesContra,
                entidad.Rival,
                entidad.Equipo,
                entidad.Cancha
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Partidos",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Partidos Modificar(Partidos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Partidos.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el partido");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Fecha,
                existente.GolesFavor,
                existente.GolesContra,
                existente.Rival,
                existente.Equipo,
                existente.Cancha
            });

            existente.Fecha = entidad.Fecha;
            existente.GolesFavor = entidad.GolesFavor;
            existente.GolesContra = entidad.GolesContra;
            existente.Rival = entidad.Rival;
            existente.Equipo = entidad.Equipo;
            existente.Cancha = entidad.Cancha;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Fecha,
                entidad.GolesFavor,
                entidad.GolesContra,
                entidad.Rival,
                entidad.Equipo,
                entidad.Cancha
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Partidos",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Partidos Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Partidos.Find(id);
            if (existente == null)
                throw new Exception("No existe el partido");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Fecha,
                existente.GolesFavor,
                existente.GolesContra,
                existente.Rival,
                existente.Equipo,
                existente.Cancha
            });

            iConexion.Partidos.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Partidos",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }
        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}