﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class EstadisticasNegocio : IEstadisticasNegocio
    {
        private IConexion? iConexion;

        public List<Estadisticas> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Estadisticas
                .Include(e => e._Jugador)
                .ToList();
        }

        public Estadisticas ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var estadistica = iConexion.Estadisticas
                .Include(e => e._Jugador)
                .FirstOrDefault(e => e.Id == id);
            if (estadistica == null)
                throw new Exception("No existe la estadística");
            return estadistica;
        }

        public Estadisticas ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Estadisticas
                .FirstOrDefault(e => e.Jugador == jugadorId);
        }

        public Estadisticas Guardar(Estadisticas entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Estadisticas.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Goles,
                entidad.Asistencias,
                entidad.TarjetasAmarillas,
                entidad.TarjetasRojas,
                entidad.Jugador
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Estadisticas",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Estadisticas Modificar(Estadisticas entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Estadisticas.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la estadística");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Goles,
                existente.Asistencias,
                existente.TarjetasAmarillas,
                existente.TarjetasRojas,
                existente.Jugador
            });

            existente.Goles = entidad.Goles;
            existente.Asistencias = entidad.Asistencias;
            existente.TarjetasAmarillas = entidad.TarjetasAmarillas;
            existente.TarjetasRojas = entidad.TarjetasRojas;
            existente.Jugador = entidad.Jugador;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Goles,
                entidad.Asistencias,
                entidad.TarjetasAmarillas,
                entidad.TarjetasRojas,
                entidad.Jugador
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Estadisticas",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Estadisticas Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Estadisticas.Find(id);
            if (existente == null)
                throw new Exception("No existe la estadística");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Goles,
                existente.Asistencias,
                existente.TarjetasAmarillas,
                existente.TarjetasRojas,
                existente.Jugador
            });

            iConexion.Estadisticas.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Estadisticas",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}