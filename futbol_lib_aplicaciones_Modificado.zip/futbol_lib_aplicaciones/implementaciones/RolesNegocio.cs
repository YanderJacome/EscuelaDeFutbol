﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class RolesNegocio : IRolesNegocio
    {
        private IConexion? iConexion;

        public List<Roles> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Roles.ToList();
        }

        public Roles ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var rol = iConexion.Roles.Find(id);
            if (rol == null)
                throw new Exception("No existe el rol");
            return rol;
        }

        public Roles Guardar(Roles entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.FechaCreacion = DateTime.Now;

            iConexion.Roles.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Descripcion,
                entidad.Activo
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Roles",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Roles Modificar(Roles entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Roles.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el rol");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Descripcion,
                existente.Activo
            });

            existente.Nombre = entidad.Nombre;
            existente.Descripcion = entidad.Descripcion;
            existente.Activo = entidad.Activo;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Descripcion,
                entidad.Activo
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Roles",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Roles Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Roles.Find(id);
            if (existente == null)
                throw new Exception("No existe el rol");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Descripcion,
                existente.Activo
            });

            iConexion.Roles.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Roles",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}
