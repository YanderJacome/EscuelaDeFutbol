﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class SedesNegocio : ISedesNegocio
    {
        private IConexion? iConexion;

        public List<Sedes> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Sedes.ToList();
        }

        public Sedes ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var sede = iConexion.Sedes.Find(id);
            if (sede == null)
                throw new Exception("No existe la sede");
            return sede;
        }

        public List<Sedes> ConsultarActivas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Sedes.Where(s => s.Activa).ToList();
        }

        public Sedes Guardar(Sedes entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Sedes.Add(entidad);
            iConexion.SaveChanges();

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Direccion,
                entidad.Ciudad,
                entidad.Activa
            });

            var auditoria = new Auditorias()
            {
                Tabla = "Sedes",
                RegistroId = entidad.Id,
                Accion = "INSERT",
                ValorAnterior = null,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return entidad;
        }

        public Sedes Modificar(Sedes entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Sedes.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la sede");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Direccion,
                existente.Ciudad,
                existente.Activa
            });

            existente.Nombre = entidad.Nombre;
            existente.Direccion = entidad.Direccion;
            existente.Ciudad = entidad.Ciudad;
            existente.Activa = entidad.Activa;

            var valorNuevo = JsonConvert.SerializeObject(new
            {
                entidad.Nombre,
                entidad.Direccion,
                entidad.Ciudad,
                entidad.Activa
            });

            iConexion.Entry(existente).State = EntityState.Modified;
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Sedes",
                RegistroId = entidad.Id,
                Accion = "UPDATE",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };

            iConexion.Auditorias!.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        public Sedes Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Sedes.Find(id);
            if (existente == null)
                throw new Exception("No existe la sede");

            var valorAnterior = JsonConvert.SerializeObject(new
            {
                existente.Nombre,
                existente.Direccion,
                existente.Ciudad,
                existente.Activa
            });

            iConexion.Sedes.Remove(existente);
            iConexion.SaveChanges();

            var auditoria = new Auditorias()
            {
                Tabla = "Sedes",
                RegistroId = id,
                Accion = "DELETE",
                ValorAnterior = valorAnterior,
                ValorNuevo = null,
                Usuario = ObtenerUsuarioActual(),
                Fecha = DateTime.Now,
                IpAddress = ObtenerIpAddress()
            };
            iConexion.Auditorias.Add(auditoria);
            iConexion.SaveChanges();

            return existente;
        }

        private int ObtenerUsuarioActual()
        {
            var usuario = iConexion!.Usuarios!.FirstOrDefault(u => u.Username == "admin");
            if (usuario != null)
                return usuario.Id;

            var cualquierUsuario = iConexion!.Usuarios!.FirstOrDefault();
            if (cualquierUsuario != null)
                return cualquierUsuario.Id;

            return 45;
        }

        private string ObtenerIpAddress()
        {
            return "127.0.0.1";
        }
    }
}