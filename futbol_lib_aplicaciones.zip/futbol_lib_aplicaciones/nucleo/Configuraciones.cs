﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.nucleo
{
    public class Configuraciones
    {
        public static string Obtener(string clave)
        {
            return "server=localhost;database=db_EscuelaDeFutbol;Integrated Security=True;TrustServerCertificate=true;";
        }
    }
}