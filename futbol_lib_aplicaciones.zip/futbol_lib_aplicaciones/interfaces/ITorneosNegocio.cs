﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface ITorneosNegocio
    {
        List<Torneos> Consultar();
        Torneos ConsultarPorId(int id);
        List<Torneos> ConsultarPorFecha(DateTime fecha);
        List<Torneos> ConsultarActivos();
        Torneos Guardar(Torneos entidad);
        Torneos Modificar(Torneos entidad);
        Torneos Borrar(int id);
    }
}