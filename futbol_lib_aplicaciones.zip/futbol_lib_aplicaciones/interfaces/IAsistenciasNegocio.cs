﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IAsistenciasNegocio
    {
        List<Asistencias> Consultar();
        Asistencias ConsultarPorId(int id);
        List<Asistencias> ConsultarPorJugador(int jugadorId);
        List<Asistencias> ConsultarPorEntrenamiento(int entrenamientoId);
        List<Asistencias> ConsultarPorFecha(DateTime fecha);
        Asistencias Guardar(Asistencias entidad);
        Asistencias Modificar(Asistencias entidad);
        Asistencias Borrar(int id);
    }
}