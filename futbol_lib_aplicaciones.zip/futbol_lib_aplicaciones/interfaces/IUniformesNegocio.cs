﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IUniformesNegocio
    {
        List<Uniformes> Consultar();
        Uniformes ConsultarPorId(int id);
        List<Uniformes> ConsultarPorEquipo(int equipoId);
        List<Uniformes> ConsultarPorTalla(string talla);
        Uniformes Guardar(Uniformes entidad);
        Uniformes Modificar(Uniformes entidad);
        Uniformes Borrar(int id);
    }
}
