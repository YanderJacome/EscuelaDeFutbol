﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IEntrenamientosNegocio
    {
        List<Entrenamientos> Consultar();
        Entrenamientos ConsultarPorId(int id);
        List<Entrenamientos> ConsultarPorFecha(DateTime fecha);
        List<Entrenamientos> ConsultarPorTipo(string tipo);
        Entrenamientos Guardar(Entrenamientos entidad);
        Entrenamientos Modificar(Entrenamientos entidad);
        Entrenamientos Borrar(int id);
    }
}