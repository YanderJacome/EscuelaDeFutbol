﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IEquiposNegocio
    {
        List<Equipos> Consultar();
        Equipos ConsultarPorId(int id);
        List<Equipos> ConsultarPorCategoria(int categoriaId);
        List<Equipos> ConsultarPorEntrenador(int entrenadorId);
        Equipos Guardar(Equipos entidad);
        Equipos Modificar(Equipos entidad);
        Equipos Borrar(int id);
    }
}