﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface ICanchasNegocio
    {
        List<Canchas> Consultar();
        Canchas ConsultarPorId(int id);
        List<Canchas> ConsultarDisponibles();
        List<Canchas> ConsultarPorCapacidad(int capacidadMinima);
        Canchas Guardar(Canchas entidad);
        Canchas Modificar(Canchas entidad);
        Canchas Borrar(int id);
    }
}