﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IMensualidadesNegocio
    {
        List<Mensualidades> Consultar();
        Mensualidades ConsultarPorId(int id);
        List<Mensualidades> ConsultarPorJugador(int jugadorId);
        List<Mensualidades> ConsultarPorEstado(bool pagada);
        List<Mensualidades> ConsultarVencidas();
        Mensualidades Guardar(Mensualidades entidad);
        Mensualidades Modificar(Mensualidades entidad);
        Mensualidades Borrar(int id);
    }
}