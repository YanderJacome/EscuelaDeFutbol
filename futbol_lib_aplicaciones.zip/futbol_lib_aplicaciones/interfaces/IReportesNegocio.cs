﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IReportesNegocio
    {
        List<Reportes> Consultar();
        Reportes ConsultarPorId(int id);
        List<Reportes> ConsultarPorUsuario(int usuarioId);
        List<Reportes> ConsultarPorTipo(string tipo);
        Reportes Guardar(Reportes entidad);
        Reportes Modificar(Reportes entidad);
        Reportes Borrar(int id);
    }
}