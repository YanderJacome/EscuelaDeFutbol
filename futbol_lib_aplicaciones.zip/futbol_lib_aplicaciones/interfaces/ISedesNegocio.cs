﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface ISedesNegocio
    {
        List<Sedes> Consultar();
        Sedes ConsultarPorId(int id);
        List<Sedes> ConsultarActivas();
        Sedes Guardar(Sedes entidad);
        Sedes Modificar(Sedes entidad);
        Sedes Borrar(int id);
    }
}