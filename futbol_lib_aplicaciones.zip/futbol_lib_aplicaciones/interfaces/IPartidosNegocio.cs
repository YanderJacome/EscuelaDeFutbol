﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IPartidosNegocio
    {
        List<Partidos> Consultar();
        Partidos ConsultarPorId(int id);
        List<Partidos> ConsultarPorEquipo(int equipoId);
        List<Partidos> ConsultarPorFecha(DateTime fecha);
        Partidos Guardar(Partidos entidad);
        Partidos Modificar(Partidos entidad);
        Partidos Borrar(int id);
    }
}