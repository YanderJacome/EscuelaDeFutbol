﻿using futbol_lib_aplicaciones.entidades;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;


namespace futbol_lib_aplicaciones.interfaces
{
    public interface IConexion
    {
        string? string_conexion { get; set; }

        // DbSets para todas las entidades
        DbSet<Personas> Personas { get; set; }
        DbSet<Jugadores> Jugadores { get; set; }
        DbSet<Entrenadores> Entrenadores { get; set; }
        DbSet<Equipos> Equipos { get; set; }
        DbSet<Pagos> Pagos { get; set; }
        DbSet<Partidos> Partidos { get; set; }
        DbSet<Estadisticas> Estadisticas { get; set; }
        DbSet<Entrenamientos> Entrenamientos { get; set; }
        DbSet<Evaluaciones> Evaluaciones { get; set; }
        DbSet<Torneos> Torneos { get; set; }
        DbSet<Posiciones> Posiciones { get; set; }
        DbSet<Lesiones> Lesiones { get; set; }
        DbSet<Uniformes> Uniformes { get; set; }
        DbSet<Sedes> Sedes { get; set; }
        DbSet<Horarios> Horarios { get; set; }
        DbSet<Inscripciones> Inscripciones { get; set; }
        DbSet<Asistencias> Asistencias { get; set; }
        DbSet<Categorias> Categorias { get; set; }
        DbSet<Notificaciones> Notificaciones { get; set; }
        DbSet<Roles> Roles { get; set; }
        DbSet<Mensualidades> Mensualidades { get; set; }
        DbSet<Usuarios> Usuarios { get; set; }
        DbSet<Auditorias> Auditorias { get; set; }
        DbSet<Canchas> Canchas { get; set; }
        DbSet<Reportes> Reportes { get; set; }

        // Métodos
        EntityEntry<T> Entry<T>(T entity) where T : class;
        int SaveChanges();
    }
}