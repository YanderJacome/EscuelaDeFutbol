﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IPosicionesNegocio
    {
        List<Posiciones> Consultar();
        Posiciones ConsultarPorId(int id);
        List<Posiciones> ConsultarPorTorneo(int torneoId);
        List<Posiciones> ConsultarPorEquipo(int equipoId);
        Posiciones Guardar(Posiciones entidad);
        Posiciones Modificar(Posiciones entidad);
        Posiciones Borrar(int id);
    }
}