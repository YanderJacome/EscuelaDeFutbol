﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IEvaluacionesNegocio
    {
        List<Evaluaciones> Consultar();
        Evaluaciones ConsultarPorId(int id);
        List<Evaluaciones> ConsultarPorJugador(int jugadorId);
        Evaluaciones Guardar(Evaluaciones entidad);
        Evaluaciones Modificar(Evaluaciones entidad);
        Evaluaciones Borrar(int id);
    }
}