﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface ICategoriasNegocio
    {
        List<Categorias> Consultar();
        Categorias ConsultarPorId(int id);
        List<Categorias> ConsultarActivas();
        List<Categorias> ConsultarPorEdad(int edad);
        Categorias Guardar(Categorias entidad);
        Categorias Modificar(Categorias entidad);
        Categorias Borrar(int id);
    }
}
