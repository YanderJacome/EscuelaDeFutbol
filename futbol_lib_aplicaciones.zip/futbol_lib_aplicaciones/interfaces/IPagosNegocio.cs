﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IPagosNegocio
    {
        List<Pagos> Consultar();
        Pagos ConsultarPorId(int id);
        List<Pagos> ConsultarPorJugador(int jugadorId);
        List<Pagos> ConsultarPorEstado(bool estado);
        Pagos Guardar(Pagos entidad);
        Pagos Modificar(Pagos entidad);
        Pagos Borrar(int id);
    }
}