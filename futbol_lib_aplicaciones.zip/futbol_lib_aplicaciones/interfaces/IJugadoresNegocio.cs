﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    
    public interface IJugadoresNegocio
    {
        List<Jugadores> Consultar();
        Jugadores ConsultarPorId(int id);
        Jugadores Guardar(Jugadores entidad);
        Jugadores Modificar(Jugadores entidad);
        Jugadores Borrar(int id);
        List<Jugadores> ConsultarPorEquipo(int equipoId);
    }
}