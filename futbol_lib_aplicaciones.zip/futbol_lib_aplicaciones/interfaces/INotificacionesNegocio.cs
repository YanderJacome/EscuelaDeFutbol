﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface INotificacionesNegocio
    {
        List<Notificaciones> Consultar();
        Notificaciones ConsultarPorId(int id);
        List<Notificaciones> ConsultarPorJugador(int jugadorId);
        List<Notificaciones> ConsultarNoLeidas();
        List<Notificaciones> ConsultarPorFecha(DateTime fecha);
        Notificaciones Guardar(Notificaciones entidad);
        Notificaciones Modificar(Notificaciones entidad);
        Notificaciones Borrar(int id);
    }
}
