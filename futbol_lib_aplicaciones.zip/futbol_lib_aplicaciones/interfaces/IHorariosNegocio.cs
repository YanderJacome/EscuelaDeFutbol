﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IHorariosNegocio
    {
        List<Horarios> Consultar();
        Horarios ConsultarPorId(int id);
        List<Horarios> ConsultarPorEquipo(int equipoId);
        List<Horarios> ConsultarPorDia(DayOfWeek dia);
        List<Horarios> ConsultarActivos();
        Horarios Guardar(Horarios entidad);
        Horarios Modificar(Horarios entidad);
        Horarios Borrar(int id);
    }
}