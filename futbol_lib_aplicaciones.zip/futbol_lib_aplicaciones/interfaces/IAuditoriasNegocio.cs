﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IAuditoriasNegocio
    {
        List<Auditorias> Consultar();
        Auditorias ConsultarPorId(int id);
        List<Auditorias> ConsultarPorUsuario(int usuarioId);
        List<Auditorias> ConsultarPorTabla(string tabla);
        List<Auditorias> ConsultarPorFecha(DateTime fecha);
        Auditorias Guardar(Auditorias entidad);
        Auditorias Modificar(Auditorias entidad);
        Auditorias Borrar(int id);
        void RegistrarAuditoria(string tabla, int registroId, string accion, string valorAnterior, string valorNuevo, int usuarioId, string ipAddress);
    }
}