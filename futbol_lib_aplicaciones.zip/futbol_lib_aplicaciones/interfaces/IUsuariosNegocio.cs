﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IUsuariosNegocio
    {
        List<Usuarios> Consultar();
        Usuarios ConsultarPorId(int id);
        Usuarios ConsultarPorUsername(string username);
        Usuarios Guardar(Usuarios entidad);
        Usuarios Modificar(Usuarios entidad);
        Usuarios Borrar(int id);
        Usuarios Autenticar(string username, string password);
        bool CambiarPassword(int id, string nuevaPassword);
    }
}