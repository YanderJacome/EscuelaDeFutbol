﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IEntrenadoresNegocio
    {
        List<Entrenadores> Consultar();
        Entrenadores ConsultarPorId(int id);
        Entrenadores Guardar(Entrenadores entidad);
        Entrenadores Modificar(Entrenadores entidad);
        Entrenadores Borrar(int id);
        List<Entrenadores> ConsultarPorRol(int rolId);
    }
}