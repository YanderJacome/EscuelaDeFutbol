﻿using futbol_lib_aplicaciones.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.interfaces
{
    public interface IRolesNegocio
    {
        List<Roles> Consultar();
        Roles ConsultarPorId(int id);
        Roles Guardar(Roles entidad);
        Roles Modificar(Roles entidad);
        Roles Borrar(int id);
    }
}