﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class CategoriasNegocio : ICategoriasNegocio
    {
        private IConexion? iConexion;

        public List<Categorias> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Categorias.ToList();
        }

        public Categorias ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var categoria = iConexion.Categorias.Find(id);
            if (categoria == null)
                throw new Exception("No existe la categoría");
            return categoria;
        }

        public List<Categorias> ConsultarActivas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Categorias.Where(c => c.Activa).ToList();
        }

        public List<Categorias> ConsultarPorEdad(int edad)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Categorias.Where(c => c.EdadMinima <= edad && edad <= c.EdadMaxima && c.Activa).ToList();
        }

        public Categorias Guardar(Categorias entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Categorias.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Categorias Modificar(Categorias entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Categorias.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la categoría");

            existente.Nombre = entidad.Nombre;
            existente.EdadMinima = entidad.EdadMinima;
            existente.EdadMaxima = entidad.EdadMaxima;
            existente.Activa = entidad.Activa;

            iConexion.SaveChanges();
            return existente;
        }

        public Categorias Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Categorias.Find(id);
            if (existente == null)
                throw new Exception("No existe la categoría");

            iConexion.Categorias.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}