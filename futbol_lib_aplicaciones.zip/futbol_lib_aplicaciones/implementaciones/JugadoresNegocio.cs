﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class JugadoresNegocio : IJugadoresNegocio
    {
        private IConexion? iConexion;

        public List<Jugadores> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Jugadores.ToList();
        }

        public Jugadores ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var jugador = iConexion.Jugadores.Find(id);
            if (jugador == null)
                throw new Exception("No existe el jugador");
            return jugador;
        }

        public List<Jugadores> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Jugadores.Where(j => j.Equipo == equipoId).ToList();
        }

        public Jugadores Guardar(Jugadores entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Jugadores.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Jugadores Modificar(Jugadores entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Jugadores.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el jugador");

            existente.Nombre = entidad.Nombre;
            existente.Documento = entidad.Documento;
            existente.FechaNacimiento = entidad.FechaNacimiento;
            existente.Telefono = entidad.Telefono;
            existente.Email = entidad.Email;
            existente.Direccion = entidad.Direccion;
            existente.Activo = entidad.Activo;
            existente.Posicion = entidad.Posicion;
            existente.PiernaHabil = entidad.PiernaHabil;
            existente.Equipo = entidad.Equipo;

            iConexion.SaveChanges();
            return existente;
        }

        public Jugadores Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Jugadores.Find(id);
            if (existente == null)
                throw new Exception("No existe el jugador");

            iConexion.Jugadores.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}