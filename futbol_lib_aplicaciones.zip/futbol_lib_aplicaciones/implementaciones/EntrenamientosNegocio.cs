﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class EntrenamientosNegocio : IEntrenamientosNegocio
    {
        private IConexion? iConexion;

        public List<Entrenamientos> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Entrenamientos.ToList();
        }

        public Entrenamientos ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var entrenamiento = iConexion.Entrenamientos.Find(id);
            if (entrenamiento == null)
                throw new Exception("No existe el entrenamiento");
            return entrenamiento;
        }

        public List<Entrenamientos> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Entrenamientos.Where(e => e.Fecha.Date == fecha.Date).ToList();
        }

        public List<Entrenamientos> ConsultarPorTipo(string tipo)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Entrenamientos.Where(e => e.Tipo == tipo).ToList();
        }

        public Entrenamientos Guardar(Entrenamientos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Entrenamientos.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Entrenamientos Modificar(Entrenamientos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Entrenamientos.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el entrenamiento");

            existente.Fecha = entidad.Fecha;
            existente.DuracionMinutos = entidad.DuracionMinutos;
            existente.Tipo = entidad.Tipo;
            existente.Completado = entidad.Completado;

            iConexion.SaveChanges();
            return existente;
        }

        public Entrenamientos Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Entrenamientos.Find(id);
            if (existente == null)
                throw new Exception("No existe el entrenamiento");

            iConexion.Entrenamientos.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}