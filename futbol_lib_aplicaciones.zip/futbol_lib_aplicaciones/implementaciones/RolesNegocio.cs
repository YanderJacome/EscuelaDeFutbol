﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class RolesNegocio : IRolesNegocio
    {
        private IConexion? iConexion;

        public List<Roles> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Roles.ToList();
        }

        public Roles ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var rol = iConexion.Roles.Find(id);
            if (rol == null)
                throw new Exception("No existe el rol");
            return rol;
        }

        public Roles Guardar(Roles entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Roles.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Roles Modificar(Roles entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Roles.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el rol");

            existente.Nombre = entidad.Nombre;
            existente.Descripcion = entidad.Descripcion;
            existente.Activo = entidad.Activo;
            existente.FechaCreacion = entidad.FechaCreacion;

            iConexion.SaveChanges();
            return existente;
        }

        public Roles Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Roles.Find(id);
            if (existente == null)
                throw new Exception("No existe el rol");

            iConexion.Roles.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}
