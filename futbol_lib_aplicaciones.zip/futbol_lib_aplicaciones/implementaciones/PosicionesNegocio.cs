﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class PosicionesNegocio : IPosicionesNegocio
    {
        private IConexion? iConexion;

        public List<Posiciones> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Posiciones.ToList();
        }

        public Posiciones ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var posicion = iConexion.Posiciones.Find(id);
            if (posicion == null)
                throw new Exception("No existe la posición");
            return posicion;
        }

        public List<Posiciones> ConsultarPorTorneo(int torneoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Posiciones.Where(p => p.Torneo == torneoId).OrderByDescending(p => p.Puntos).ToList();
        }

        public List<Posiciones> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Posiciones.Where(p => p.Equipo == equipoId).ToList();
        }

        public Posiciones Guardar(Posiciones entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Posiciones.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Posiciones Modificar(Posiciones entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Posiciones.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la posición");

            existente.Puntos = entidad.Puntos;
            existente.PartidosJugados = entidad.PartidosJugados;
            existente.DiferenciaGoles = entidad.DiferenciaGoles;
            existente.Equipo = entidad.Equipo;
            existente.Torneo = entidad.Torneo;

            iConexion.SaveChanges();
            return existente;
        }

        public Posiciones Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Posiciones.Find(id);
            if (existente == null)
                throw new Exception("No existe la posición");

            iConexion.Posiciones.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}
