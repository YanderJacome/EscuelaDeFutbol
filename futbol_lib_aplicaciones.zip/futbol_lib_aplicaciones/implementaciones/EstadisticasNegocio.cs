﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class EstadisticasNegocio : IEstadisticasNegocio
    {
        private IConexion? iConexion;

        public List<Estadisticas> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Estadisticas.ToList();
        }

        public Estadisticas ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var estadistica = iConexion.Estadisticas.Find(id);
            if (estadistica == null)
                throw new Exception("No existe la estadística");
            return estadistica;
        }

        public Estadisticas ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Estadisticas.FirstOrDefault(e => e.Jugador == jugadorId);
        }

        public Estadisticas Guardar(Estadisticas entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Estadisticas.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Estadisticas Modificar(Estadisticas entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Estadisticas.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la estadística");

            existente.Goles = entidad.Goles;
            existente.Asistencias = entidad.Asistencias;
            existente.TarjetasAmarillas = entidad.TarjetasAmarillas;
            existente.TarjetasRojas = entidad.TarjetasRojas;
            existente.Jugador = entidad.Jugador;

            iConexion.SaveChanges();
            return existente;
        }

        public Estadisticas Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Estadisticas.Find(id);
            if (existente == null)
                throw new Exception("No existe la estadística");

            iConexion.Estadisticas.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}