﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class SedesNegocio : ISedesNegocio
    {
        private IConexion? iConexion;

        public List<Sedes> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Sedes.ToList();
        }

        public Sedes ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var sede = iConexion.Sedes.Find(id);
            if (sede == null)
                throw new Exception("No existe la sede");
            return sede;
        }

        public List<Sedes> ConsultarActivas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Sedes.Where(s => s.Activa).ToList();
        }

        public Sedes Guardar(Sedes entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Sedes.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Sedes Modificar(Sedes entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Sedes.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la sede");

            existente.Nombre = entidad.Nombre;
            existente.Direccion = entidad.Direccion;
            existente.Ciudad = entidad.Ciudad;
            existente.Activa = entidad.Activa;

            iConexion.SaveChanges();
            return existente;
        }

        public Sedes Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Sedes.Find(id);
            if (existente == null)
                throw new Exception("No existe la sede");

            iConexion.Sedes.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}