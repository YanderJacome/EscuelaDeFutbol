﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class MensualidadesNegocio : IMensualidadesNegocio
    {
        private IConexion? iConexion;

        public List<Mensualidades> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Mensualidades.ToList();
        }

        public Mensualidades ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var mensualidad = iConexion.Mensualidades.Find(id);
            if (mensualidad == null)
                throw new Exception("No existe la mensualidad");
            return mensualidad;
        }

        public List<Mensualidades> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Mensualidades.Where(m => m.Jugador == jugadorId).ToList();
        }

        public List<Mensualidades> ConsultarPorEstado(bool pagada)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Mensualidades.Where(m => m.Pagada == pagada).ToList();
        }

        public List<Mensualidades> ConsultarVencidas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var hoy = DateTime.Now;
            return iConexion.Mensualidades.Where(m => !m.Pagada && m.FechaVencimiento.Date < hoy.Date).ToList();
        }

        public Mensualidades Guardar(Mensualidades entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Mensualidades.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Mensualidades Modificar(Mensualidades entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Mensualidades.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la mensualidad");

            existente.ValorBase = entidad.ValorBase;
            existente.Recargo = entidad.Recargo;
            existente.FechaVencimiento = entidad.FechaVencimiento;
            existente.Pagada = entidad.Pagada;
            existente.Jugador = entidad.Jugador;

            iConexion.SaveChanges();
            return existente;
        }

        public Mensualidades Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Mensualidades.Find(id);
            if (existente == null)
                throw new Exception("No existe la mensualidad");

            iConexion.Mensualidades.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}