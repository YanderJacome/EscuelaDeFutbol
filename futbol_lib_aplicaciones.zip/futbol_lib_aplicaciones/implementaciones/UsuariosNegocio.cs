﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using System.Security.Cryptography;
using System.Text;


namespace futbol_lib_aplicaciones.implementaciones
{
    public class UsuariosNegocio : IUsuariosNegocio
    {
        private IConexion? iConexion;

        private string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(password);
            var hash = sha256.ComputeHash(bytes);
            return Convert.ToBase64String(hash);
        }

        public List<Usuarios> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Usuarios.ToList();
        }

        public Usuarios ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var usuario = iConexion.Usuarios.Find(id);
            if (usuario == null)
                throw new Exception("No existe el usuario");
            return usuario;
        }

        public Usuarios ConsultarPorUsername(string username)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var usuario = iConexion.Usuarios.FirstOrDefault(u => u.Username == username);
            if (usuario == null)
                throw new Exception("No existe el usuario");
            return usuario;
        }

        public Usuarios Guardar(Usuarios entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.PasswordHash = HashPassword(entidad.PasswordHash);
            entidad.FechaCreacion = DateTime.Now;
            entidad.Activo = true;

            iConexion.Usuarios.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Usuarios Modificar(Usuarios entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Usuarios.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el usuario");

            existente.Username = entidad.Username;
            existente.Email = entidad.Email;
            existente.Rol = entidad.Rol;
            existente.Activo = entidad.Activo;

            if (!string.IsNullOrEmpty(entidad.PasswordHash))
            {
                existente.PasswordHash = HashPassword(entidad.PasswordHash);
            }

            iConexion.SaveChanges();
            return existente;
        }

        public Usuarios Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Usuarios.Find(id);
            if (existente == null)
                throw new Exception("No existe el usuario");

            iConexion.Usuarios.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }

        public Usuarios Autenticar(string username, string password)
        {
            var usuario = ConsultarPorUsername(username);
            var hash = HashPassword(password);

            if (usuario.PasswordHash != hash)
                throw new Exception("Contraseña incorrecta");

            if (!usuario.Activo)
                throw new Exception("Usuario inactivo");

            return usuario;
        }

        public bool CambiarPassword(int id, string nuevaPassword)
        {
            var usuario = ConsultarPorId(id);
            usuario.PasswordHash = HashPassword(nuevaPassword);
            Modificar(usuario);
            return true;
        }
    }
}