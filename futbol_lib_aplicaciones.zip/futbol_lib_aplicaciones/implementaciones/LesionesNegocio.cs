﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class LesionesNegocio : ILesionesNegocio
    {
        private IConexion? iConexion;

        public List<Lesiones> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Lesiones.ToList();
        }

        public Lesiones ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var lesion = iConexion.Lesiones.Find(id);
            if (lesion == null)
                throw new Exception("No existe la lesión");
            return lesion;
        }

        public List<Lesiones> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Lesiones.Where(l => l.Jugador == jugadorId).ToList();
        }

        public List<Lesiones> ConsultarActivas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Lesiones.Where(l => l.FechaFin == null).ToList();
        }

        public Lesiones Guardar(Lesiones entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Lesiones.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Lesiones Modificar(Lesiones entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Lesiones.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la lesión");

            existente.Tipo = entidad.Tipo;
            existente.FechaInicio = entidad.FechaInicio;
            existente.FechaFin = entidad.FechaFin;
            existente.Observacion = entidad.Observacion;
            existente.Jugador = entidad.Jugador;

            iConexion.SaveChanges();
            return existente;
        }

        public Lesiones Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Lesiones.Find(id);
            if (existente == null)
                throw new Exception("No existe la lesión");

            iConexion.Lesiones.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}