﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class EquiposNegocio : IEquiposNegocio
    {
        private IConexion? iConexion;

        public List<Equipos> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Equipos.ToList();
        }

        public Equipos ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var equipo = iConexion.Equipos.Find(id);
            if (equipo == null)
                throw new Exception("No existe el equipo");
            return equipo;
        }

        public List<Equipos> ConsultarPorCategoria(int categoriaId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Equipos.Where(e => e.Categoria == categoriaId).ToList();
        }

        public List<Equipos> ConsultarPorEntrenador(int entrenadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Equipos.Where(e => e.Entrenador == entrenadorId).ToList();
        }

        public Equipos Guardar(Equipos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Equipos.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Equipos Modificar(Equipos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Equipos.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el equipo");

            existente.Nombre = entidad.Nombre;
            existente.Activo = entidad.Activo;
            existente.Entrenador = entidad.Entrenador;
            existente.Categoria = entidad.Categoria;

            iConexion.SaveChanges();
            return existente;
        }

        public Equipos Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Equipos.Find(id);
            if (existente == null)
                throw new Exception("No existe el equipo");

            iConexion.Equipos.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}
