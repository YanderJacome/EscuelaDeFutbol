﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;


namespace futbol_lib_aplicaciones.implementaciones
{
    public class PagosNegocio : IPagosNegocio
    {
        private IConexion? iConexion;

        public List<Pagos> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Pagos.ToList();
        }

        public Pagos ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var pago = iConexion.Pagos.Find(id);
            if (pago == null)
                throw new Exception("No existe el pago");
            return pago;
        }

        public List<Pagos> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Pagos.Where(p => p.Jugador == jugadorId).ToList();
        }

        public List<Pagos> ConsultarPorEstado(bool estado)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Pagos.Where(p => p.Estado == estado).ToList();
        }

        public Pagos Guardar(Pagos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Pagos.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Pagos Modificar(Pagos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Pagos.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el pago");

            existente.Fecha = entidad.Fecha;
            existente.Valor = entidad.Valor;
            existente.Descuento = entidad.Descuento;
            existente.Estado = entidad.Estado;
            existente.Jugador = entidad.Jugador;

            iConexion.SaveChanges();
            return existente;
        }

        public Pagos Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Pagos.Find(id);
            if (existente == null)
                throw new Exception("No existe el pago");

            iConexion.Pagos.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}