﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class HorariosNegocio : IHorariosNegocio
    {
        private IConexion? iConexion;

        public List<Horarios> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Horarios.ToList();
        }

        public Horarios ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var horario = iConexion.Horarios.Find(id);
            if (horario == null)
                throw new Exception("No existe el horario");
            return horario;
        }

        public List<Horarios> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Horarios.Where(h => h.Equipo == equipoId).ToList();
        }

        public List<Horarios> ConsultarPorDia(DayOfWeek dia)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Horarios.Where(h => h.Dia == dia && h.Activo).ToList();
        }

        public List<Horarios> ConsultarActivos()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Horarios.Where(h => h.Activo).ToList();
        }

        public Horarios Guardar(Horarios entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Horarios.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Horarios Modificar(Horarios entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Horarios.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el horario");

            existente.Dia = entidad.Dia;
            existente.HoraInicio = entidad.HoraInicio;
            existente.HoraFin = entidad.HoraFin;
            existente.Activo = entidad.Activo;
            existente.Equipo = entidad.Equipo;

            iConexion.SaveChanges();
            return existente;
        }

        public Horarios Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Horarios.Find(id);
            if (existente == null)
                throw new Exception("No existe el horario");

            iConexion.Horarios.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}