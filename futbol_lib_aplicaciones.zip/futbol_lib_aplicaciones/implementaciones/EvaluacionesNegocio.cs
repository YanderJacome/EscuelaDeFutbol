﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class EvaluacionesNegocio : IEvaluacionesNegocio
    {
        private IConexion? iConexion;

        public List<Evaluaciones> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Evaluaciones.ToList();
        }

        public Evaluaciones ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var evaluacion = iConexion.Evaluaciones.Find(id);
            if (evaluacion == null)
                throw new Exception("No existe la evaluación");
            return evaluacion;
        }

        public List<Evaluaciones> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Evaluaciones.Where(e => e.Jugador == jugadorId).ToList();
        }

        public Evaluaciones Guardar(Evaluaciones entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Evaluaciones.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Evaluaciones Modificar(Evaluaciones entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Evaluaciones.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la evaluación");

            existente.Resistencia = entidad.Resistencia;
            existente.Velocidad = entidad.Velocidad;
            existente.Tecnica = entidad.Tecnica;
            existente.Disciplina = entidad.Disciplina;
            existente.Jugador = entidad.Jugador;

            iConexion.SaveChanges();
            return existente;
        }

        public Evaluaciones Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Evaluaciones.Find(id);
            if (existente == null)
                throw new Exception("No existe la evaluación");

            iConexion.Evaluaciones.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}
