﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class PartidosNegocio : IPartidosNegocio
    {
        private IConexion? iConexion;

        public List<Partidos> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Partidos.ToList();
        }

        public Partidos ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var partido = iConexion.Partidos.Find(id);
            if (partido == null)
                throw new Exception("No existe el partido");
            return partido;
        }

        public List<Partidos> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Partidos.Where(p => p.Equipo == equipoId).ToList();
        }

        public List<Partidos> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Partidos.Where(p => p.Fecha.Date == fecha.Date).ToList();
        }

        public Partidos Guardar(Partidos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Partidos.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Partidos Modificar(Partidos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Partidos.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el partido");

            existente.Fecha = entidad.Fecha;
            existente.GolesFavor = entidad.GolesFavor;
            existente.GolesContra = entidad.GolesContra;
            existente.Rival = entidad.Rival;
            existente.Equipo = entidad.Equipo;
            existente.Cancha = entidad.Cancha;

            iConexion.SaveChanges();
            return existente;
        }

        public Partidos Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Partidos.Find(id);
            if (existente == null)
                throw new Exception("No existe el partido");

            iConexion.Partidos.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}
