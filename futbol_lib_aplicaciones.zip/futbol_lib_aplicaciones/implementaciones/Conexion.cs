﻿
using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class Conexion : DbContext, IConexion
    {
        public string? string_conexion { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(this.string_conexion!, p => { });
            optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
        }

        public DbSet<Personas> Personas { get; set; }
        public DbSet<Jugadores> Jugadores { get; set; }
        public DbSet<Entrenadores> Entrenadores { get; set; }
        public DbSet<Equipos> Equipos { get; set; }
        public DbSet<Pagos> Pagos { get; set; }
        public DbSet<Partidos> Partidos { get; set; }
        public DbSet<Estadisticas> Estadisticas { get; set; }
        public DbSet<Entrenamientos> Entrenamientos { get; set; }
        public DbSet<Evaluaciones> Evaluaciones { get; set; }
        public DbSet<Torneos> Torneos { get; set; }
        public DbSet<Posiciones> Posiciones { get; set; }
        public DbSet<Lesiones> Lesiones { get; set; }
        public DbSet<Uniformes> Uniformes { get; set; }
        public DbSet<Sedes> Sedes { get; set; }
        public DbSet<Horarios> Horarios { get; set; }
        public DbSet<Inscripciones> Inscripciones { get; set; }
        public DbSet<Asistencias> Asistencias { get; set; }
        public DbSet<Categorias> Categorias { get; set; }
        public DbSet<Notificaciones> Notificaciones { get; set; }
        public DbSet<Roles> Roles { get; set; }
        public DbSet<Mensualidades> Mensualidades { get; set; }
        public DbSet<Usuarios> Usuarios { get; set; }
        public DbSet<Auditorias> Auditorias { get; set; }
        public DbSet<Canchas> Canchas { get; set; }
        public DbSet<Reportes> Reportes { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

           

            modelBuilder.Entity<Jugadores>()
                .ToTable("Jugadores")
                .HasBaseType<Personas>();

            modelBuilder.Entity<Entrenadores>()
                .ToTable("Entrenadores")
                .HasBaseType<Personas>();

           
            modelBuilder.Entity<Jugadores>()
                .HasOne(j => j._Equipo)
                .WithMany(e => e.Jugadores)
                .HasForeignKey(j => j.Equipo)
                .OnDelete(DeleteBehavior.Restrict);

     
            modelBuilder.Entity<Entrenadores>()
                .HasOne(e => e._Rol)
                .WithMany(r => r.Entrenadores)
                .HasForeignKey(e => e.Rol);

            modelBuilder.Entity<Entrenadores>()
                .HasMany(e => e.Equipos)
                .WithOne(eq => eq._Entrenador)
                .HasForeignKey(eq => eq.Entrenador);

       
            modelBuilder.Entity<Equipos>()
                .HasOne(e => e._Categoria)
                .WithMany(c => c.Equipos)
                .HasForeignKey(e => e.Categoria);
        }

 
        }
    }
