﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class AsistenciasNegocio : IAsistenciasNegocio
    {
        private IConexion? iConexion;

        public List<Asistencias> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Asistencias.ToList();
        }

        public Asistencias ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var asistencia = iConexion.Asistencias.Find(id);
            if (asistencia == null)
                throw new Exception("No existe la asistencia");
            return asistencia;
        }

        public List<Asistencias> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Asistencias.Where(a => a.Jugador == jugadorId).ToList();
        }

        public List<Asistencias> ConsultarPorEntrenamiento(int entrenamientoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Asistencias.Where(a => a.Entrenamiento == entrenamientoId).ToList();
        }

        public List<Asistencias> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Asistencias.Where(a => a.Fecha.Date == fecha.Date).ToList();
        }

        public Asistencias Guardar(Asistencias entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.Fecha = DateTime.Now;
            iConexion.Asistencias.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Asistencias Modificar(Asistencias entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Asistencias.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la asistencia");

            existente.Fecha = entidad.Fecha;
            existente.Presente = entidad.Presente;
            existente.Observacion = entidad.Observacion;
            existente.Entrenamiento = entidad.Entrenamiento;
            existente.Jugador = entidad.Jugador;

            iConexion.SaveChanges();
            return existente;
        }

        public Asistencias Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Asistencias.Find(id);
            if (existente == null)
                throw new Exception("No existe la asistencia");

            iConexion.Asistencias.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}