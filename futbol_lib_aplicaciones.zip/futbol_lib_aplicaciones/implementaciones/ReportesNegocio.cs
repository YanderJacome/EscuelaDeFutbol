﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class ReportesNegocio : IReportesNegocio
    {
        private IConexion? iConexion;

        public List<Reportes> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Reportes.OrderByDescending(r => r.FechaGeneracion).ToList();
        }

        public Reportes ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var reporte = iConexion.Reportes.Find(id);
            if (reporte == null)
                throw new Exception("No existe el reporte");
            return reporte;
        }

        public List<Reportes> ConsultarPorUsuario(int usuarioId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Reportes.Where(r => r.GeneradoPor == usuarioId).OrderByDescending(r => r.FechaGeneracion).ToList();
        }

        public List<Reportes> ConsultarPorTipo(string tipo)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Reportes.Where(r => r.Tipo == tipo).OrderByDescending(r => r.FechaGeneracion).ToList();
        }

        public Reportes Guardar(Reportes entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.FechaGeneracion = DateTime.Now;
            iConexion.Reportes.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Reportes Modificar(Reportes entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Reportes.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el reporte");

            existente.Nombre = entidad.Nombre;
            existente.Tipo = entidad.Tipo;
            existente.Parametros = entidad.Parametros;
            existente.ArchivoUrl = entidad.ArchivoUrl;

            iConexion.SaveChanges();
            return existente;
        }

        public Reportes Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Reportes.Find(id);
            if (existente == null)
                throw new Exception("No existe el reporte");

            iConexion.Reportes.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}