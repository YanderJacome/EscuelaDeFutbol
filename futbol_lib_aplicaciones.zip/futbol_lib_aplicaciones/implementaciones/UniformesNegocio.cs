﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class UniformesNegocio : IUniformesNegocio
    {
        private IConexion? iConexion;

        public List<Uniformes> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Uniformes.ToList();
        }

        public Uniformes ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var uniforme = iConexion.Uniformes.Find(id);
            if (uniforme == null)
                throw new Exception("No existe el uniforme");
            return uniforme;
        }

        public List<Uniformes> ConsultarPorEquipo(int equipoId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Uniformes.Where(u => u.Equipo == equipoId).ToList();
        }

        public List<Uniformes> ConsultarPorTalla(string talla)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Uniformes.Where(u => u.Talla == talla).ToList();
        }

        public Uniformes Guardar(Uniformes entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Uniformes.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Uniformes Modificar(Uniformes entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Uniformes.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el uniforme");

            existente.ColorPrincipal = entidad.ColorPrincipal;
            existente.ColorSecundario = entidad.ColorSecundario;
            existente.Talla = entidad.Talla;
            existente.NumeroDisponible = entidad.NumeroDisponible;
            existente.Equipo = entidad.Equipo;

            iConexion.SaveChanges();
            return existente;
        }

        public Uniformes Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Uniformes.Find(id);
            if (existente == null)
                throw new Exception("No existe el uniforme");

            iConexion.Uniformes.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}