﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class EntrenadoresNegocio : IEntrenadoresNegocio
    {
        private IConexion? iConexion;

        public List<Entrenadores> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Entrenadores.ToList();
        }

        public Entrenadores ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var entrenador = iConexion.Entrenadores.Find(id);
            if (entrenador == null)
                throw new Exception("No existe el entrenador");
            return entrenador;
        }

        public List<Entrenadores> ConsultarPorRol(int rolId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Entrenadores.Where(e => e.Rol == rolId).ToList();
        }

        public Entrenadores Guardar(Entrenadores entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Entrenadores.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Entrenadores Modificar(Entrenadores entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Entrenadores.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el entrenador");

            existente.Nombre = entidad.Nombre;
            existente.Documento = entidad.Documento;
            existente.FechaNacimiento = entidad.FechaNacimiento;
            existente.Telefono = entidad.Telefono;
            existente.Email = entidad.Email;
            existente.Direccion = entidad.Direccion;
            existente.Activo = entidad.Activo;
            existente.Licencia = entidad.Licencia;
            existente.Experiencia = entidad.Experiencia;
            existente.Especialidad = entidad.Especialidad;
            existente.Rol = entidad.Rol;

            iConexion.SaveChanges();
            return existente;
        }

        public Entrenadores Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Entrenadores.Find(id);
            if (existente == null)
                throw new Exception("No existe el entrenador");

            iConexion.Entrenadores.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}