﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class InscripcionesNegocio : IInscripcionesNegocio
    {
        private IConexion? iConexion;

        public List<Inscripciones> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Inscripciones.ToList();
        }

        public Inscripciones ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var inscripcion = iConexion.Inscripciones.Find(id);
            if (inscripcion == null)
                throw new Exception("No existe la inscripción");
            return inscripcion;
        }

        public List<Inscripciones> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Inscripciones.Where(i => i.Jugador == jugadorId).ToList();
        }

        public List<Inscripciones> ConsultarPorEstado(bool estado)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Inscripciones.Where(i => i.Estado == estado).ToList();
        }

        public Inscripciones Guardar(Inscripciones entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.Fecha = DateTime.Now;
            iConexion.Inscripciones.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Inscripciones Modificar(Inscripciones entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Inscripciones.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la inscripción");

            existente.Fecha = entidad.Fecha;
            existente.Valor = entidad.Valor;
            existente.Estado = entidad.Estado;
            existente.Jugador = entidad.Jugador;

            iConexion.SaveChanges();
            return existente;
        }

        public Inscripciones Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Inscripciones.Find(id);
            if (existente == null)
                throw new Exception("No existe la inscripción");

            iConexion.Inscripciones.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}