﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class CanchasNegocio : ICanchasNegocio
    {
        private IConexion? iConexion;

        public List<Canchas> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Canchas.ToList();
        }

        public Canchas ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var cancha = iConexion.Canchas.Find(id);
            if (cancha == null)
                throw new Exception("No existe la cancha");
            return cancha;
        }

        public List<Canchas> ConsultarDisponibles()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Canchas.Where(c => c.Disponible).ToList();
        }

        public List<Canchas> ConsultarPorCapacidad(int capacidadMinima)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Canchas.Where(c => c.Capacidad >= capacidadMinima).ToList();
        }

        public Canchas Guardar(Canchas entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Canchas.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Canchas Modificar(Canchas entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Canchas.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la cancha");

            existente.Nombre = entidad.Nombre;
            existente.Ubicacion = entidad.Ubicacion;
            existente.Latitud = entidad.Latitud;
            existente.Longitud = entidad.Longitud;
            existente.Capacidad = entidad.Capacidad;
            existente.Disponible = entidad.Disponible;

            iConexion.SaveChanges();
            return existente;
        }

        public Canchas Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Canchas.Find(id);
            if (existente == null)
                throw new Exception("No existe la cancha");

            iConexion.Canchas.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}