﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;


namespace futbol_lib_aplicaciones.implementaciones
{
    public class PersonasNegocio : IPersonasNegocio
    {
        private IConexion? iConexion;

        public List<Personas> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Personas.ToList();
        }

        public Personas ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var persona = iConexion.Personas.Find(id);
            if (persona == null)
                throw new Exception("No existe la persona");
            return persona;
        }

        public Personas Guardar(Personas entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Personas.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Personas Modificar(Personas entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Personas.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la persona");

            existente.Nombre = entidad.Nombre;
            existente.Documento = entidad.Documento;
            existente.FechaNacimiento = entidad.FechaNacimiento;
            existente.Telefono = entidad.Telefono;
            existente.Email = entidad.Email;
            existente.Direccion = entidad.Direccion;
            existente.Activo = entidad.Activo;

            iConexion.SaveChanges();
            return existente;
        }

        public Personas Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Personas.Find(id);
            if (existente == null)
                throw new Exception("No existe la persona");

            iConexion.Personas.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}