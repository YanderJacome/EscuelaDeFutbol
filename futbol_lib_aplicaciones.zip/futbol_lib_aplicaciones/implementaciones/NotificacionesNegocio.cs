﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class NotificacionesNegocio : INotificacionesNegocio
    {
        private IConexion? iConexion;

        public List<Notificaciones> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Notificaciones.OrderByDescending(n => n.Fecha).ToList();
        }

        public Notificaciones ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var notificacion = iConexion.Notificaciones.Find(id);
            if (notificacion == null)
                throw new Exception("No existe la notificación");
            return notificacion;
        }

        public List<Notificaciones> ConsultarPorJugador(int jugadorId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Notificaciones.Where(n => n.Jugador == jugadorId).OrderByDescending(n => n.Fecha).ToList();
        }

        public List<Notificaciones> ConsultarNoLeidas()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Notificaciones.Where(n => !n.Leida).OrderByDescending(n => n.Fecha).ToList();
        }

        public List<Notificaciones> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Notificaciones.Where(n => n.Fecha.Date == fecha.Date).OrderByDescending(n => n.Fecha).ToList();
        }

        public Notificaciones Guardar(Notificaciones entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            entidad.Fecha = DateTime.Now;
            entidad.Leida = false;
            iConexion.Notificaciones.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Notificaciones Modificar(Notificaciones entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Notificaciones.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la notificación");

            existente.Mensaje = entidad.Mensaje;
            existente.Fecha = entidad.Fecha;
            existente.Leida = entidad.Leida;
            existente.Jugador = entidad.Jugador;

            iConexion.SaveChanges();
            return existente;
        }

        public Notificaciones Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Notificaciones.Find(id);
            if (existente == null)
                throw new Exception("No existe la notificación");

            iConexion.Notificaciones.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}
