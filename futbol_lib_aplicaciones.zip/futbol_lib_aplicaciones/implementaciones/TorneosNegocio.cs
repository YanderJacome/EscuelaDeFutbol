﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class TorneosNegocio : ITorneosNegocio
    {
        private IConexion? iConexion;

        public List<Torneos> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Torneos.ToList();
        }

        public Torneos ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var torneo = iConexion.Torneos.Find(id);
            if (torneo == null)
                throw new Exception("No existe el torneo");
            return torneo;
        }

        public List<Torneos> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Torneos.Where(t => t.FechaInicio.Date <= fecha.Date && t.FechaFin.Date >= fecha.Date).ToList();
        }

        public List<Torneos> ConsultarActivos()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var hoy = DateTime.Now;
            return iConexion.Torneos.Where(t => t.FechaInicio.Date <= hoy.Date && t.FechaFin.Date >= hoy.Date).ToList();
        }

        public Torneos Guardar(Torneos entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Torneos.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Torneos Modificar(Torneos entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Torneos.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe el torneo");

            existente.Nombre = entidad.Nombre;
            existente.FechaInicio = entidad.FechaInicio;
            existente.FechaFin = entidad.FechaFin;
            existente.Ubicacion = entidad.Ubicacion;

            iConexion.SaveChanges();
            return existente;
        }

        public Torneos Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Torneos.Find(id);
            if (existente == null)
                throw new Exception("No existe el torneo");

            iConexion.Torneos.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }
    }
}