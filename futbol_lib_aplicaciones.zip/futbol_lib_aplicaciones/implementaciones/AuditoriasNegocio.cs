﻿using futbol_lib_aplicaciones.entidades;
using futbol_lib_aplicaciones.interfaces;
using futbol_lib_aplicaciones.nucleo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.implementaciones
{
    public class AuditoriasNegocio : IAuditoriasNegocio
    {
        private IConexion? iConexion;

        public List<Auditorias> Consultar()
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Auditorias.OrderByDescending(a => a.Fecha).ToList();
        }

        public Auditorias ConsultarPorId(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            var auditoria = iConexion.Auditorias.Find(id);
            if (auditoria == null)
                throw new Exception("No existe la auditoría");
            return auditoria;
        }

        public List<Auditorias> ConsultarPorUsuario(int usuarioId)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Auditorias.Where(a => a.Usuario == usuarioId).OrderByDescending(a => a.Fecha).ToList();
        }

        public List<Auditorias> ConsultarPorTabla(string tabla)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Auditorias.Where(a => a.Tabla == tabla).OrderByDescending(a => a.Fecha).ToList();
        }

        public List<Auditorias> ConsultarPorFecha(DateTime fecha)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");
            return iConexion.Auditorias.Where(a => a.Fecha.Date == fecha.Date).OrderByDescending(a => a.Fecha).ToList();
        }

        public Auditorias Guardar(Auditorias entidad)
        {
            if (entidad.Id != 0)
                throw new Exception("Ya se guardó");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            iConexion.Auditorias.Add(entidad);
            iConexion.SaveChanges();
            return entidad;
        }

        public Auditorias Modificar(Auditorias entidad)
        {
            if (entidad.Id == 0)
                throw new Exception("No se puede modificar");

            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Auditorias.Find(entidad.Id);
            if (existente == null)
                throw new Exception("No existe la auditoría");

            existente.Tabla = entidad.Tabla;
            existente.RegistroId = entidad.RegistroId;
            existente.Accion = entidad.Accion;
            existente.ValorAnterior = entidad.ValorAnterior;
            existente.ValorNuevo = entidad.ValorNuevo;
            existente.Usuario = entidad.Usuario;
            existente.IpAddress = entidad.IpAddress;
            existente.Fecha = entidad.Fecha;

            iConexion.SaveChanges();
            return existente;
        }

        public Auditorias Borrar(int id)
        {
            iConexion = new Conexion();
            iConexion.string_conexion = Configuraciones.Obtener("string_conexion");

            var existente = iConexion.Auditorias.Find(id);
            if (existente == null)
                throw new Exception("No existe la auditoría");

            iConexion.Auditorias.Remove(existente);
            iConexion.SaveChanges();
            return existente;
        }

        public void RegistrarAuditoria(string tabla, int registroId, string accion, string valorAnterior, string valorNuevo, int usuarioId, string ipAddress)
        {
            var auditoria = new Auditorias
            {
                Tabla = tabla,
                RegistroId = registroId,
                Accion = accion,
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo,
                Usuario = usuarioId,
                IpAddress = ipAddress,
                Fecha = DateTime.Now
            };
            Guardar(auditoria);
        }
    }
}