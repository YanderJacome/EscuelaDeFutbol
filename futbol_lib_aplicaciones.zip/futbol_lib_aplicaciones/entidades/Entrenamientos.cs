﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Entrenamientos
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public int DuracionMinutos { get; set; }
        public string? Tipo { get; set; }
        public bool Completado { get; set; }
        public int Horas()
        {
            return DuracionMinutos / 60;
        }
    }
}
