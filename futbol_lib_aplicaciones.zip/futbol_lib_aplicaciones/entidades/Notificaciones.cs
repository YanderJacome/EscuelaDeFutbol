﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Notificaciones
    {
        public int Id { get; set; }
        public string? Mensaje { get; set; }
        public DateTime Fecha { get; set; }
        public bool Leida { get; set; }
        public int Jugador { get; set; }

        [ForeignKey("Jugador")]
        public Jugadores? _Jugador { get; set; }
    }
}
