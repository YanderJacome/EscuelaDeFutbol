﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Posiciones
    {
        public int Id { get; set; }
        public int Puntos { get; set; }
        public int PartidosJugados { get; set; }
        public int DiferenciaGoles { get; set; }
        public int Equipo { get; set; }
        public int Torneo { get; set; }

        [ForeignKey("Equipo")]
        public Equipos? _Equipo { get; set; }

        [ForeignKey("Torneo")]
        public Torneos? _Torneo { get; set; }
    }
}