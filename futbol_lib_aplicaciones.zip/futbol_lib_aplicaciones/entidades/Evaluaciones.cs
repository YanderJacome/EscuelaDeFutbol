﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Evaluaciones
    {
        public int Id { get; set; }
        public decimal Resistencia { get; set; }
        public decimal Velocidad { get; set; }
        public decimal Tecnica { get; set; }
        public decimal Disciplina { get; set; }
        public int Jugador { get; set; }

        [ForeignKey("Jugador")]
        public Jugadores? _Jugador { get; set; }

       
        public decimal Promedio()
        {
            return (Resistencia + Velocidad + Tecnica + Disciplina) / 4;
        }
    }
}