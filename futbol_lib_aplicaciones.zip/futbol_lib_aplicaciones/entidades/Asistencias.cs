﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Asistencias
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public bool Presente { get; set; }
        public string? Observacion { get; set; }
        public int Entrenamiento { get; set; }
        public int Jugador { get; set; }

        [ForeignKey("Entrenamiento")]
        public Entrenamientos? _Entrenamiento { get; set; }

        [ForeignKey("Jugador")]
        public Jugadores? _Jugador { get; set; }
    }
}
