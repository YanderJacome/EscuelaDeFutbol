﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Entrenadores : Personas
    {
        public string? Licencia { get; set; }
        public int Experiencia { get; set; }
        public string? Especialidad { get; set; }
        public int Rol { get; set; }

        [ForeignKey("Rol")]
        public Roles? _Rol { get; set; }

        [NotMapped]
        public List<Equipos>? Equipos { get; set; }
    }
}
