﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Uniformes
    {
        public int Id { get; set; }
        public string? ColorPrincipal { get; set; }
        public string? ColorSecundario { get; set; }
        public string? Talla { get; set; }
        public int NumeroDisponible { get; set; }
        public int Equipo { get; set; }

        [ForeignKey("Equipo")]
        public Equipos? _Equipo { get; set; }
    }
}