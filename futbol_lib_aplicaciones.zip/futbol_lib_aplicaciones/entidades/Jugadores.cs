﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Jugadores : Personas
    {
        public string? Posicion { get; set; }
        public string? PiernaHabil { get; set; }

        public int Equipo { get; set; }

        [ForeignKey("Equipo")]
        public Equipos? _Equipo { get; set; }

        [NotMapped]
        public List<Pagos>? Pagos { get; set; }

        [NotMapped]
        public List<Estadisticas>? Estadisticas { get; set; }

        [NotMapped]
        public List<Lesiones>? Lesiones { get; set; }

        [NotMapped]
        public List<Evaluaciones>? Evaluaciones { get; set; }

        [NotMapped]
        public List<Mensualidades>? Mensualidades { get; set; }

        [NotMapped]
        public List<Inscripciones>? Inscripciones { get; set; }

        [NotMapped]
        public List<Asistencias>? Asistencias { get; set; }

        [NotMapped]
        public List<Notificaciones>? Notificaciones { get; set; }
    }
}
