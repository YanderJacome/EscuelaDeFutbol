﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Equipos
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public bool Activo { get; set; }
        public int Entrenador { get; set; }
        public int Categoria { get; set; }

        [ForeignKey("Entrenador")]
        public Entrenadores? _Entrenador { get; set; }

        [ForeignKey("Categoria")]
        public Categorias? _Categoria { get; set; }

        [NotMapped]
        public List<Jugadores>? Jugadores { get; set; }

        [NotMapped]
        public List<Partidos>? Partidos { get; set; }

        [NotMapped]
        public List<Horarios>? Horarios { get; set; }

        [NotMapped]
        public List<Uniformes>? Uniformes { get; set; }

        [NotMapped]
        public List<Posiciones>? posiciones { get; set; }
    }
}