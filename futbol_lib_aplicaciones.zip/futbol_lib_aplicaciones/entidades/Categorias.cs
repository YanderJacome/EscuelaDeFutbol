﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Categorias
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public int EdadMinima { get; set; }
        public int EdadMaxima { get; set; }
        public bool Activa { get; set; }

        [NotMapped]
        public List<Equipos>? Equipos { get; set; }
    }
}
