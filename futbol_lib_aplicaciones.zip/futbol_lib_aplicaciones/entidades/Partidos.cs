﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Partidos
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public int GolesFavor { get; set; }
        public int GolesContra { get; set; }
        public string? Rival { get; set; }
        public int Equipo { get; set; }
        public int? Cancha { get; set; }

        [ForeignKey("Equipo")]
        public Equipos? _Equipo { get; set; }

        [ForeignKey("Cancha")]
        public Canchas? _Cancha { get; set; }

        public int Puntos()
        {
            if (GolesFavor > GolesContra) return 3;
            if (GolesFavor == GolesContra) return 1;
            return 0;
        }
    }
}