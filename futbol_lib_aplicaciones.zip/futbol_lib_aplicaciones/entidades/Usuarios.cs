﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Usuarios
    {
        public int Id { get; set; }
        public string? Username { get; set; }
        public string? PasswordHash { get; set; }
        public string? Email { get; set; }
        public int Rol { get; set; }
        public DateTime FechaCreacion { get; set; }
        public bool Activo { get; set; }

        [ForeignKey("Rol")]
        public Roles? _Rol { get; set; }

        [NotMapped]
        public List<Auditorias>? Auditorias { get; set; }
    }
}
