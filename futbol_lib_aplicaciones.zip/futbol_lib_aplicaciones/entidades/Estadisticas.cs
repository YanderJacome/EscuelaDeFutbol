﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Estadisticas
    {
        public int Id { get; set; }
        public int Goles { get; set; }
        public int Asistencias { get; set; }
        public int TarjetasAmarillas { get; set; }
        public int TarjetasRojas { get; set; }
        public int Jugador { get; set; }

        [ForeignKey("Jugador")]
        public Jugadores? _Jugador { get; set; }

        public int PuntosRendimiento()
        {
            return (Goles * 4) + (Asistencias * 3) - (TarjetasAmarillas * 1) - (TarjetasRojas * 3);
        }
    }
}