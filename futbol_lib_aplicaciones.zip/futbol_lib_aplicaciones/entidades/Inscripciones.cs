﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Inscripciones
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public decimal Valor { get; set; }
        public bool Estado { get; set; }
        public int Jugador { get; set; }

        [ForeignKey("Jugador")]
        public Jugadores? _Jugador { get; set; }
    }
}