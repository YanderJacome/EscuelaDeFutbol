﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Mensualidades
    {
        public int Id { get; set; }
        public decimal ValorBase { get; set; }
        public decimal Recargo { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public bool Pagada { get; set; }
        public int Jugador { get; set; }

        [ForeignKey("Jugador")]
        public Jugadores? _Jugador { get; set; }
    }
}
