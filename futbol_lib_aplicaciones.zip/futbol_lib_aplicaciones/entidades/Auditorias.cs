﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Auditorias
    {
        public int Id { get; set; }
        public string? Tabla { get; set; }
        public int RegistroId { get; set; }
        public string? Accion { get; set; }
        public string? ValorAnterior { get; set; }
        public string? ValorNuevo { get; set; }
        public int Usuario { get; set; }
        public DateTime Fecha { get; set; }
        public string? IpAddress { get; set; }

        [ForeignKey("Usuario")]
        public Usuarios? _Usuario { get; set; }
    }
}
