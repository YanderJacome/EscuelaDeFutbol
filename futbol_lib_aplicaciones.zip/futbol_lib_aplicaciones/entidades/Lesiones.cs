﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Lesiones
    {
        public int Id { get; set; }
        public string? Tipo { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime? FechaFin { get; set; }
        public string? Observacion { get; set; }
        public int Jugador { get; set; }

        [ForeignKey("Jugador")]
        public Jugadores? _Jugador { get; set; }
    }
}