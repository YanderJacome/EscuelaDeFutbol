﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futbol_lib_aplicaciones.entidades
{
    public class Canchas
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public string? Ubicacion { get; set; }
        public double Latitud { get; set; }
        public double Longitud { get; set; }
        public int Capacidad { get; set; }
        public bool Disponible { get; set; }

        [NotMapped]
        public List<Partidos>? Partidos { get; set; }
    }
}
